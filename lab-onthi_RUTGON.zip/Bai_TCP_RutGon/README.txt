BAI TCP JAVA - BAN CODE RUT GON

Cac file:
- ServerTCP.java: Server TCP port 7000, moi client duoc xu ly bang mot thread.
- ClientTCP.java: Client ket noi va chon dich vu.

CACH CHAY (CMD/PowerShell):
1. Mo terminal tai thu muc chua 2 file Java.
2. Bien dich:
   javac ServerTCP.java ClientTCP.java
3. Mo terminal thu nhat va chay server:
   java ServerTCP
4. Mo terminal thu hai va chay client:
   java ClientTCP
5. Co the mo them nhieu cua so client de kiem tra nhieu ket noi.

LUU Y:
- Port mac dinh: 7000.
- STT trong ServerTCP.java dang la 25000901 (so le), nen duoc phep dung dich vu 1 va 3.
- Neu STT cua ban khac, sua gia tri STT trong ServerTCP.java.
- Neu client chay tren may khac, sua ip = "127.0.0.1" trong ClientTCP.java thanh IP cua may server.
- Moi dong du lieu duoc gui den server; nhap mot dau cham (.) tren mot dong rieng de ket thuc nhap dich vu.
- Nhap EXIT. de ket thuc ket noi.
- Dich vu 1: dao thu tu cac tu va dao ky tu tung tu, viet hoa ky tu dau.
- Dich vu 2: giu thu tu cac tu, dao ky tu tung tu, viet hoa ky tu dau.
- Dich vu 3: dem tong so tu cua tat ca cac dong, tra ket qua sau dau cham.
- Dich vu 4: dem so tu cua tung dong, tra ket qua ngay.
- Theo quy tac de bai, STT le chi duoc chon dich vu 1, 3; STT chan chi duoc chon dich vu 2, 4.
