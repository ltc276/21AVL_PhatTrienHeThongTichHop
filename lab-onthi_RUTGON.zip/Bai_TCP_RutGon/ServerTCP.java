import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

public class ServerTCP {
    static final int PORT = 7000;
    static final int STT = 25000901; // Doi thanh STT cua ban neu can.

    public static void main(String[] args) throws IOException {
        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("TCP Server dang chay tai cong " + PORT);
            while (true) {
                Socket socket = server.accept();
                new Thread(() -> handle(socket)).start(); // Moi client mot thread.
            }
        }
    }

    static void handle(Socket socket) {
        try (Socket s = socket;
             BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(s.getOutputStream(), StandardCharsets.UTF_8), true)) {
            while (true) {
                out.println("STT " + STT + (STT % 2 == 0
                        ? " chan - chon dich vu 2 hoac 4; nhap EXIT. de thoat."
                        : " le - chon dich vu 1 hoac 3; nhap EXIT. de thoat."));

                String choice = in.readLine();
                if (choice == null) break;
                if (choice.trim().equalsIgnoreCase("EXIT.")) {
                    out.println("Server da dong ket noi voi client.");
                    break;
                }

                int service;
                try {
                    service = Integer.parseInt(choice.trim());
                } catch (NumberFormatException e) {
                    out.println("ERROR: Hay nhap so dich vu hop le.");
                    continue;
                }
                if (!allowed(service)) {
                    out.println("ERROR: STT nay khong duoc phep dung dich vu vua chon.");
                    continue;
                }

                out.println("OK: Nhap tung dong; nhap . de ket thuc.");
                int totalWords = 0;
                while (true) {
                    String line = in.readLine();
                    if (line == null) return;
                    if (line.trim().equals(".")) {
                        out.println(service == 3
                                ? "Tong so tu cua tat ca cac dong: " + totalWords
                                : "Da ket thuc dich vu " + service + ".");
                        break;
                    }

                    switch (service) {
                        case 1 -> out.println(reverse(line, true));
                        case 2 -> out.println(reverse(line, false));
                        case 3 -> totalWords += countWords(line);
                        case 4 -> out.println("So tu trong dong nay: " + countWords(line));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Client da ngat ket noi: " + e.getMessage());
        }
    }

    static boolean allowed(int service) {
        return STT % 2 == 0 ? service == 2 || service == 4 : service == 1 || service == 3;
    }

    static int countWords(String text) {
        return text.trim().isEmpty() ? 0 : text.trim().split("\\s+").length;
    }

    // reverseWords=true: dao ca thu tu cac tu; false: giu thu tu cac tu.
    static String reverse(String text, boolean reverseWords) {
        if (text.trim().isEmpty()) return "";
        String[] words = text.trim().split("\\s+");
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < words.length; i++) {
            if (i > 0) result.append(' ');
            int index = reverseWords ? words.length - 1 - i : i;
            String word = new StringBuilder(words[index].toLowerCase(Locale.ROOT)).reverse().toString();
            result.append(word.substring(0, 1).toUpperCase(Locale.ROOT)).append(word.substring(1));
        }
        return result.toString();
    }
}
