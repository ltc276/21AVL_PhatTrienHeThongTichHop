import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class ClientTCP {
    public static void main(String[] args) throws IOException {
        String ip = "127.0.0.1"; // Doi thanh IP may server neu chay tren may khac.
        int port = 7000;

        try (Socket socket = new Socket(ip, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
             Scanner sc = new Scanner(System.in, "UTF-8")) {
            System.out.println("Da ket noi TCP den server.");

            while (true) {
                String menu = in.readLine();
                if (menu == null) break;
                System.out.println("\n" + menu);
                System.out.print("Nhap dich vu hoac EXIT. de thoat: ");
                String choice = sc.nextLine().trim();
                if (choice.equalsIgnoreCase("EXIT.")) {
                    out.println("EXIT.");
                    System.out.println(in.readLine());
                    break;
                }

                out.println(choice);
                String reply = in.readLine();
                if (reply == null) break;
                System.out.println(reply);
                if (reply.startsWith("ERROR")) continue;

                int service = Integer.parseInt(choice);
                System.out.println("Nhap tung dong; nhap . de ket thuc.");
                while (true) {
                    String line = sc.nextLine();
                    out.println(line);
                    if (line.trim().equals(".")) {
                        System.out.println(in.readLine());
                        break;
                    }
                    if (service != 3) System.out.println(in.readLine());
                }
            }
        }
    }
}
