import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.*;
public class Server {
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(5103)) {
            System.out.println("TCP date/time server 5103");
            while(true) {
                Socket s=ss.accept();
                new Thread(()->serve(s)).start();
            }
        }
        catch(IOException e) {
            System.err.println(e.getMessage());
        }
    }
    static void serve(Socket s) {
        try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            String x;
            while((x=in.readLine())!=null) {
                out.println(run(x));
                if(x.equalsIgnoreCase("QUIT"))break;
            }
        }
        catch(IOException e) {
        }
    }
    static String run(String x) {
        try {
            DateTimeFormatter d=DateTimeFormatter.ofPattern("dd MM yyyy"),t=DateTimeFormatter.ofPattern("HH mm ss");
            LocalDateTime n=LocalDateTime.now();
            return switch(x.trim().toUpperCase()) {
                case "DATE"->d.format(n);
                case "TIME"->t.format(n);
                case "DATETIME"->d.format(n)+" "+t.format(n);
                case "QUIT"->"BYE";
                default->"ERR UNKNOWN_COMMAND";
            }
            ;
        }
        catch(Exception e) {
            return "ERR";
        }
    }
}
