LAB 04 - BÀI 3 / TCP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  TCP port 5103

Ghi chú: Thử DATE, TIME, DATETIME; TCP có QUIT đóng phiên. UDP không có phiên kết nối nên QUIT chỉ là thông điệp kết thúc vòng nhập của client.
