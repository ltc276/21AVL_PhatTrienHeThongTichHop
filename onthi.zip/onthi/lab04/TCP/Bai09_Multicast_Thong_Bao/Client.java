import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        try(Socket s=new Socket(a.length>0?a[0]:"localhost",5109);BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true);Scanner sc=new Scanner(System.in)) {
            System.out.print("Nickname: ");
            out.println(sc.nextLine());
            System.out.println(in.readLine());
            Thread t=new Thread(()-> {
                try {
                    String x;while((x=in.readLine())!=null)System.out.println(x);
                }
                catch(Exception ignored) {
                }
            }
            );
            t.setDaemon(true);
            t.start();
            System.out.println("Nhap thong bao; QUIT de dung");
            while(true) {
                String x=sc.nextLine();
                out.println(x);
                if(x.equals("QUIT"))break;
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
