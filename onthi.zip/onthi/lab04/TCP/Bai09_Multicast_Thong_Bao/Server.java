import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
public class Server {
    static final Map<Socket,PrintWriter> clients=new ConcurrentHashMap<>();
    static final ExecutorService pool=Executors.newFixedThreadPool(20);
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(5109)) {
            System.out.println("TCP notification relay 5109; mỗi client gửi nickname trước");
            while(true) {
                Socket s=ss.accept();
                pool.submit(()->run(s));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void run(Socket s) {
        try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            String name=in.readLine();
            if(name==null)return;
            clients.put(s,out);
            out.println("OK JOIN "+name);
            String line;
            while((line=in.readLine())!=null&&!line.equals("QUIT")) {
                for(var e:clients.entrySet())if(e.getKey()!=s)e.getValue().println("NOTICE "+name+": "+line);
            }
            out.println("BYE");
        }
        catch(Exception e) {
        }
        finally {
            clients.remove(s);
        }
    }
}
