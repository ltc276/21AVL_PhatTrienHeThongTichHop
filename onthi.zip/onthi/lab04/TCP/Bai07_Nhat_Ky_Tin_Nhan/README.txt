LAB 04 - BÀI 7 / TCP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  TCP port 5107

Ghi chú: Sau khi gửi HELLO clientId, mỗi dòng được append vào data/logs/clientId.txt cùng timestamp và địa chỉ remote; QUIT kết thúc.
