import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.concurrent.*;
public class Server {
    static final int PORT=5107;
    static final ExecutorService pool=Executors.newFixedThreadPool(30);
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(PORT)) {
            System.out.println("Log server TCP "+PORT);
            while(true) {
                Socket client=ss.accept();
                pool.submit(()->serve(client));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void serve(Socket s) {
        String id=null;
        try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            String hello=in.readLine();
            if(hello==null||!hello.startsWith("HELLO ")) {
                out.println("ERR HELLO_REQUIRED");
                return;
            }
            id=hello.substring(6).trim();
            if(!id.matches("[A-Za-z0-9_-]+")) {
                out.println("ERR INVALID_CLIENT_ID");
                return;
            }
            out.println("OK");
            String line;
            while((line=in.readLine())!=null) {
                if(line.equals("QUIT")) {
                    out.println("BYE");
                    break;
                }
                Files.createDirectories(Path.of("data","logs"));
                String log=Instant.now()+" | "+s.getRemoteSocketAddress()+" | "+line+System.lineSeparator();
                Files.writeString(Path.of("data","logs",id+".txt"),log,StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);
                out.println("SAVED");
            }
        }
        catch(Exception e) {
            System.err.println("Log: "+e.getMessage());
        }
    }
}
