import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    static final int PORT=5101;
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(PORT)) {
            System.out.println("TCP Host/URI server port "+PORT);
            while(true) {
                Socket s=ss.accept();
                new Thread(()->serve(s)).start();
            }
        }
        catch(IOException e) {
            System.err.println(e.getMessage());
        }
    }
    static void serve(Socket s) {
        try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            String req=in.readLine();
            out.println(inspect(req));
        }
        catch(IOException e) {
            System.err.println(e.getMessage());
        }
    }
    static String inspect(String req) {
        try {
            String[] p=req.split("\\t",2);
            if(p.length!=2)return "ERR FORMAT: gui hostname<TAB>URI";
            StringBuilder b=new StringBuilder("HOST "+p[0]);
            for(InetAddress ip:InetAddress.getAllByName(p[0]))b.append(" | IP=").append(ip.getHostAddress()).append(" type=").append(ip instanceof Inet4Address?"IPv4":"IPv6").append(" loopback=").append(ip.isLoopbackAddress()).append(" siteLocal=").append(ip.isSiteLocalAddress());
            URI u=new URI(p[1]);
            b.append(" | URI scheme=").append(u.getScheme()).append(" host=").append(u.getHost()).append(" port=").append(u.getPort()).append(" path=").append(u.getPath()).append(" query=").append(u.getQuery()).append(" fragment=").append(u.getFragment());
            return b.toString();
        }
        catch(Exception e) {
            return "ERR "+e.getClass().getSimpleName()+": "+e.getMessage();
        }
    }
}
