import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        String server=a.length>0?a[0]:"localhost";
        try(Scanner sc=new Scanner(System.in)) {
            System.out.print("Hostname can tra: ");
            String host=sc.nextLine();
            System.out.print("URI can phan tich: ");
            String uri=sc.nextLine();
            try(Socket s=new Socket(server,5101);BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
                out.println(host+"\t"+uri);
                System.out.println(in.readLine());
            }
        }
        catch(Exception e) {
            System.err.println("Loi client: "+e.getMessage());
        }
    }
}
