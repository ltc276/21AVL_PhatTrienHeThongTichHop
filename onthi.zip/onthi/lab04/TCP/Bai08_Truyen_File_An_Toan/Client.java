import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.HexFormat;
public class Client {
    static String sha(byte[] b)throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));
    }
    public static void main(String[]a) {
        if(a.length<1) {
            System.out.println("Cach dung: java Client <file-can-gui> [server-ip]");
            return;
        }
        try {
            Path f=Path.of(a[0]);
            byte[] data=Files.readAllBytes(f);
            try(Socket s=new Socket(a.length>1?a[1]:"localhost",5108);DataOutputStream out=new DataOutputStream(new BufferedOutputStream(s.getOutputStream()));DataInputStream in=new DataInputStream(new BufferedInputStream(s.getInputStream()))) {
                out.writeUTF(f.getFileName().toString());
                out.writeLong(data.length);
                out.writeUTF(sha(data));
                out.write(data);
                out.flush();
                System.out.println(in.readUTF());
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
