LAB 04 - BÀI 8 / TCP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client data/source.txt localhost

Giao thức/cảng:
  TCP port 5108

Ghi chú: Client truyền một file đã có; Server chỉ lưu tên file an toàn vào upload/. Bản UDP giới hạn 1 MiB, chia gói 900 byte và chờ ACK từng gói.
