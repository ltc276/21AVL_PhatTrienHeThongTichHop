import java.io.*;
import java.net.*;
import java.nio.file.*;
import java.security.*;
import java.util.HexFormat;
public class Server {
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(5108)) {
            System.out.println("TCP file receiver port 5108; output in upload/");
            while(true) {
                Socket s=ss.accept();
                new Thread(()->serve(s)).start();
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static String sha(byte[] b)throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));
    }
    static void serve(Socket s) {
        try(s;DataInputStream in=new DataInputStream(new BufferedInputStream(s.getInputStream()));DataOutputStream out=new DataOutputStream(new BufferedOutputStream(s.getOutputStream()))) {
            String name=in.readUTF();
            long size=in.readLong();
            String expected=in.readUTF();
            if(name.isBlank()||name.contains("..")||name.contains("/")||name.contains("\\")||size<0||size>20_000_000) {
                out.writeUTF("ERR INVALID_METADATA");
                out.flush();
                return;
            }
            byte[] data=in.readNBytes((int)size);
            if(data.length!=size) {
                out.writeUTF("ERR SIZE_MISMATCH");
                out.flush();
                return;
            }
            if(!sha(data).equalsIgnoreCase(expected)) {
                out.writeUTF("ERR HASH_MISMATCH");
                out.flush();
                return;
            }
            Path dir=Path.of("upload");
            Files.createDirectories(dir);
            Files.write(dir.resolve(Path.of(name).getFileName().toString()),data);
            out.writeUTF("OK SHA256="+sha(data)+" SIZE="+size);
            out.flush();
        }
        catch(Exception e) {
            System.err.println("File receive: "+e.getMessage());
        }
    }
}
