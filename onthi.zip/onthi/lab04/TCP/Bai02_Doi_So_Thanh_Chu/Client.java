import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        String host=a.length>0?a[0]:"localhost";
        try(Socket s=new Socket(host,5102);BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true);Scanner sc=new Scanner(System.in)) {
            System.out.println("Nhap mot chu so 0-9; QUIT de dung");
            while(true) {
                String x=sc.nextLine();
                out.println(x);
                System.out.println(in.readLine());
                if(x.equalsIgnoreCase("QUIT"))break;
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
