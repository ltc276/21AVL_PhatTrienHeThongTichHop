import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    static final int PORT=5102;
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(PORT)) {
            System.out.println("TCP digit server "+PORT);
            while(true) {
                Socket s=ss.accept();
                new Thread(()->serve(s)).start();
            }
        }
        catch(IOException e) {
            System.err.println(e.getMessage());
        }
    }
    static void serve(Socket s) {
        try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            String line;
            while((line=in.readLine())!=null) {
                if(line.equalsIgnoreCase("QUIT")) {
                    out.println("BYE");
                    break;
                }
                out.println(convert(line));
            }
        }
        catch(IOException e) {
            System.err.println(e.getMessage());
        }
    }
    static String convert(String x) {
        String[] words= {
            "không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"
        }
        ;
        return x!=null&&x.matches("[0-9]")?"OK "+words[x.charAt(0)-'0']:"ERR INVALID_DIGIT";
    }
}
