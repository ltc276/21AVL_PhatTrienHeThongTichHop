LAB 04 - BÀI 2 / TCP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  TCP port 5102

Ghi chú: Gửi từng ký tự số 0-9 để nhận cách đọc tiếng Việt; nhập QUIT để dừng client.
