import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(5104)) {
            System.out.println("TCP calculator 5104");
            while(true) {
                Socket s=ss.accept();
                new Thread(()->serve(s)).start();
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void serve(Socket s) {
        try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            String x;
            while((x=in.readLine())!=null) {
                out.println(calc(x));
                if(x.equalsIgnoreCase("QUIT"))break;
            }
        }
        catch(Exception e) {
        }
    }
    static String calc(String req) {
        if(req.trim().equalsIgnoreCase("QUIT"))return "BYE";
        try {
            String[] p=req.trim().split("\\s+");
            if(p.length!=4||!p[0].equalsIgnoreCase("CALC"))return "ERR INVALID_FORMAT";
            double x=Double.parseDouble(p[2]),y=Double.parseDouble(p[3]);
            double r=switch(p[1]) {
                case "+"->x+y;
                case "-"->x-y;
                case "*"->x*y;
                case "/"-> {
                    if(y==0)throw new ArithmeticException("DIVIDE_BY_ZERO");
                    yield x/y;
                }
                default->throw new UnsupportedOperationException("UNSUPPORTED_OPERATOR");
            }
            ;
            return "OK "+r;
        }
        catch(ArithmeticException e) {
            return "ERR DIVIDE_BY_ZERO";
        }
        catch(UnsupportedOperationException e) {
            return "ERR UNSUPPORTED_OPERATOR";
        }
        catch(NumberFormatException e) {
            return "ERR INVALID_NUMBER";
        }
        catch(Exception e) {
            return "ERR INVALID_FORMAT";
        }
    }
}
