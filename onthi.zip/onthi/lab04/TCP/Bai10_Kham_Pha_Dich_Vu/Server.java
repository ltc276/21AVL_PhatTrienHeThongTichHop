import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    static final int PORT=5110;
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(PORT)) {
            System.out.println("TCP service discovery on "+PORT);
            while(true) {
                Socket s=ss.accept();
                new Thread(()->serve(s)).start();
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void serve(Socket s) {
        try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            out.println("SERVICE DemoService 5110 v1");
            String line=in.readLine();
            out.println("OK "+line);
        }
        catch(Exception e) {
        }
    }
}
