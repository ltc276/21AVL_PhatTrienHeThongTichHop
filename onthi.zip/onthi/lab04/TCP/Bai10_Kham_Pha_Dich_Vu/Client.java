import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class Client {
    public static void main(String[]a) {
        try(Socket s=new Socket(a.length>0?a[0]:"localhost",5110);BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
            System.out.println("Service: "+in.readLine());
            out.println("PING");
            System.out.println("Phan hoi: "+in.readLine());
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
