LAB 04 - BÀI 10 / TCP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  TCP port 5110

Ghi chú: Chạy Server trước, sau đó Client. Dùng UTF-8; giữ đúng lệnh giao thức ghi trong console.
