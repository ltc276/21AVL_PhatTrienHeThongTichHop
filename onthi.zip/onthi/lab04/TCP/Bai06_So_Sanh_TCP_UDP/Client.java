import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class Client {
    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        try {
            for (int round = 1; round <= 5; round++) {
                long start = System.nanoTime();
                int received = 0;
                try (Socket socket = new Socket(host, 5106);
                     BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
                     PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true)) {
                    for (int i = 0; i < 1000; i++) out.println("PING-" + i + "-XXXXXXXXXXXXXXXX");
                    for (int i = 0; i < 1000; i++) if (in.readLine() != null) received++;
                }
                System.out.printf("Lan %d: phan hoi %d/1000, %.2f ms%n", round, received, (System.nanoTime() - start) / 1_000_000.0);
            }
        } catch (Exception e) { System.err.println("Benchmark TCP: " + e.getMessage()); }
    }
}
