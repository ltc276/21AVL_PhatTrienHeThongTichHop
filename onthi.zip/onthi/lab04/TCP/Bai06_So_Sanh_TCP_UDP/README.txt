LAB 04 - BÀI 6 / TCP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  TCP port 5106

Ghi chú: Client chạy 5 lượt, mỗi lượt gửi 1000 bản tin rồi đếm phản hồi; bản UDP thu trong cửa sổ tối đa 2 giây. Chỉ dùng làm phép đo thực nghiệm; kết quả phụ thuộc máy, buffer và mạng.
