import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(5106)) {
            System.out.println("TCP benchmark server 5106");
            while(true) {
                Socket s=ss.accept();
                new Thread(()-> {
                    try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
                        String x;while((x=in.readLine())!=null)out.println(x);
                    }
                    catch(Exception e) {
                    }
                }
                ).start();
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
