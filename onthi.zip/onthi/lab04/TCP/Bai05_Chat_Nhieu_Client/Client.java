import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        String host=a.length>0?a[0]:"localhost";
        try(Socket s=new Socket(host,5105);BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true);Scanner sc=new Scanner(System.in)) {
            System.out.print("Nickname: ");
            out.println("NICK "+sc.nextLine());
            String ack=in.readLine();
            System.out.println(ack);
            if(ack==null||ack.startsWith("ERR"))return;
            Thread recv=new Thread(()-> {
                try {
                    String x;while((x=in.readLine())!=null)System.out.println(x);
                }
                catch(Exception ignored) {
                }
            }
            );
            recv.setDaemon(true);
            recv.start();
            System.out.println("Nhap tin nhan; /users xem danh sach; /quit thoat");
            while(true) {
                String x=sc.nextLine();
                if(x.equalsIgnoreCase("/users"))out.println("USERS");
                else if(x.equalsIgnoreCase("/quit")) {
                    out.println("QUIT");
                    break;
                }
                else out.println("MSG "+x);
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
