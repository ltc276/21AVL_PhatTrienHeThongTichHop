import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
public class Server {
    static final int PORT=5105;
    static final Map<Socket,Handler> clients=new ConcurrentHashMap<>();
    static final Set<String> names=ConcurrentHashMap.newKeySet();
    static final ExecutorService pool=Executors.newFixedThreadPool(30);
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(PORT)) {
            System.out.println("Chat TCP port "+PORT);
            while(true)pool.submit(new Handler(ss.accept()));
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
        finally {
            pool.shutdown();
        }
    }
    static void broadcast(String msg,Socket exclude) {
        for(var e:clients.entrySet())if(e.getKey()!=exclude)e.getValue().send(msg);
    }
    static class Handler implements Runnable {
        Socket s;
        PrintWriter out;
        String nick;
        boolean registered;
        Handler(Socket s) {
            this.s=s;
        }
        void send(String x) {
            if(out!=null)out.println(x);
        }
        public void run() {
            Socket socket=s;
            try(socket;BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8))) {
                out=new PrintWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.UTF_8),true);
                String first=in.readLine();
                if(first==null||!first.startsWith("NICK ")) {
                    send("ERR NICK_REQUIRED");
                    return;
                }
                nick=first.substring(5).trim();
                if(!nick.matches("[A-Za-z0-9_-]{1,20}")||!names.add(nick)) {
                    send("ERR NICK_INVALID_OR_USED");
                    return;
                }
                clients.put(s,this);
                registered=true;
                send("OK Welcome "+nick);
                broadcast("JOIN "+nick,s);
                String line;
                while((line=in.readLine())!=null) {
                    if(line.equalsIgnoreCase("USERS")) {
                        send("USERS "+String.join(", ",names));
                    }
                    else if(line.startsWith("MSG ")) {
                        broadcast("MSG "+nick+": "+line.substring(4),s);
                        send("OK SENT");
                    }
                    else if(line.equalsIgnoreCase("QUIT")) {
                        send("BYE");
                        break;
                    }
                    else send("ERR UNKNOWN_COMMAND");
                }
            }
            catch(Exception e) {
                System.err.println("Client chat: "+e.getMessage());
            }
            finally {
                if(registered) {
                    clients.remove(s);
                    names.remove(nick);
                    broadcast("LEFT "+nick,s);
                }
            }
        }
    }
}
