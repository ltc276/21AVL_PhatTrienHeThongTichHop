import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class UdpEchoClient {
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket();Scanner sc=new Scanner(System.in)) {
            s.setSoTimeout(3000);
            InetAddress h=InetAddress.getByName(a.length>0?a[0]:"localhost");
            while(true) {
                String x=sc.nextLine();
                byte[] b=x.getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(b,b.length,h,5001));
                byte[] r=new byte[4096];
                DatagramPacket p=new DatagramPacket(r,r.length);
                s.receive(p);
                System.out.println(new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8));
                if(x.equals("QUIT"))break;
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
