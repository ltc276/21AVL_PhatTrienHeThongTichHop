VÍ DỤ SOCKET CƠ BẢN
TCP: biên dịch `javac TcpEchoServer.java TcpEchoClient.java`; terminal 1 chạy `java TcpEchoServer`; terminal 2 chạy `java TcpEchoClient localhost`. Gửi nhiều dòng, QUIT kết thúc.
UDP: biên dịch `javac UdpEchoServer.java UdpEchoClient.java`; terminal 1 chạy `java UdpEchoServer`; terminal 2 chạy `java UdpEchoClient localhost`. UDP dùng từng datagram và có timeout ở client.
Cổng TCP 5000, UDP 5001.
