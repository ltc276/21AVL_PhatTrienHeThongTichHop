import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class TcpEchoClient {
    public static void main(String[]a) {
        try(Socket s=new Socket(a.length>0?a[0]:"localhost",5000);BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true);Scanner sc=new Scanner(System.in)) {
            System.out.println("Nhap dong; QUIT de dung");
            while(true) {
                String x=sc.nextLine();
                out.println(x);
                System.out.println(in.readLine());
                if(x.equals("QUIT"))break;
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
