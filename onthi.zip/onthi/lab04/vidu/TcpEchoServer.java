import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class TcpEchoServer {
    public static void main(String[]a) {
        try(ServerSocket ss=new ServerSocket(5000)) {
            System.out.println("TCP Echo port 5000");
            while(true) {
                Socket s=ss.accept();
                new Thread(()-> {
                    try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
                        String x;while((x=in.readLine())!=null) {
                            out.println("ECHO "+x);if(x.equals("QUIT"))break;
                        }
                    }
                    catch(Exception e) {
                    }
                }
                ).start();
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
