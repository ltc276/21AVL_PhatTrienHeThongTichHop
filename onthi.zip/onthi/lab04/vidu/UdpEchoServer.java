import java.net.*;
import java.nio.charset.StandardCharsets;
public class UdpEchoServer {
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(5001)) {
            System.out.println("UDP Echo port 5001");
            byte[] b=new byte[4096];
            while(true) {
                DatagramPacket p=new DatagramPacket(b,b.length);
                s.receive(p);
                String x=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                byte[] r=("ECHO "+x).getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(r,r.length,p.getAddress(),p.getPort()));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
