import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        String host=a.length>0?a[0]:"localhost";
        try(Scanner sc=new Scanner(System.in);DatagramSocket s=new DatagramSocket()) {
            s.setSoTimeout(3000);
            System.out.println("Nhap mot chu so 0-9; QUIT de dung");
            while(true) {
                String x=sc.nextLine();
                byte[] b=x.getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(b,b.length,InetAddress.getByName(host),5202));
                byte[] r=new byte[2048];
                DatagramPacket p=new DatagramPacket(r,r.length);
                s.receive(p);
                String ans=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                System.out.println(ans);
                if(x.equalsIgnoreCase("QUIT"))break;
            }
        }
        catch(Exception e) {
            System.err.println("Loi/timeout: "+e.getMessage());
        }
    }
}
