import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(5202)) {
            System.out.println("UDP digit server 5202");
            byte[] buf=new byte[2048];
            while(true) {
                DatagramPacket p=new DatagramPacket(buf,buf.length);
                s.receive(p);
                String x=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                byte[] b=convert(x).getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(b,b.length,p.getAddress(),p.getPort()));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static String convert(String x) {
        String[] words= {
            "không","một","hai","ba","bốn","năm","sáu","bảy","tám","chín"
        }
        ;
        return x!=null&&x.matches("[0-9]")?"OK "+words[x.charAt(0)-'0']:x.equalsIgnoreCase("QUIT")?"BYE":"ERR INVALID_DIGIT";
    }
}
