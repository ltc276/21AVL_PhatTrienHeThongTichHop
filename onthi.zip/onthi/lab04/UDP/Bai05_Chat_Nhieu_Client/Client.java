import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        String host=a.length>0?a[0]:"localhost";
        try(DatagramSocket s=new DatagramSocket();Scanner sc=new Scanner(System.in)) {
            s.setSoTimeout(3000);
            InetAddress h=InetAddress.getByName(host);
            System.out.print("Nickname: ");
            send(s,h,"NICK "+sc.nextLine());
            System.out.println(recv(s));
            Thread t=new Thread(()-> {
                try {
                    while(true) {
                        byte[] b=new byte[4096];DatagramPacket p=new DatagramPacket(b,b.length);s.receive(p);System.out.println(new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8));
                    }
                }
                catch(Exception ignored) {
                }
            }
            );
            t.setDaemon(true);
            t.start();
            System.out.println("Nhap tin nhan; /users; /quit");
            while(true) {
                String x=sc.nextLine();
                if(x.equalsIgnoreCase("/users"))send(s,h,"USERS");
                else if(x.equalsIgnoreCase("/quit")) {
                    send(s,h,"QUIT");
                    break;
                }
                else send(s,h,"MSG "+x);
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void send(DatagramSocket s,InetAddress h,String x)throws Exception {
        byte[] b=x.getBytes(StandardCharsets.UTF_8);
        s.send(new DatagramPacket(b,b.length,h,5205));
    }
    static String recv(DatagramSocket s)throws Exception {
        byte[] b=new byte[4096];
        DatagramPacket p=new DatagramPacket(b,b.length);
        s.receive(p);
        return new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
    }
}
