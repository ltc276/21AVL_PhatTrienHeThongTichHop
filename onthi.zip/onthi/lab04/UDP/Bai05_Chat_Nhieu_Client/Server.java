import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
public class Server {
    static final int PORT=5205;
    static final Map<SocketAddress,String> clients=new ConcurrentHashMap<>();
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(PORT)) {
            System.out.println("Chat UDP port "+PORT);
            byte[] buf=new byte[4096];
            while(true) {
                DatagramPacket p=new DatagramPacket(buf,buf.length);
                s.receive(p);
                String x=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                String reply="OK";
                if(x.startsWith("NICK ")) {
                    String name=x.substring(5).trim();
                    if(!name.matches("[A-Za-z0-9_-]{1,20}")||clients.containsValue(name)) {
                        reply="ERR NICK_INVALID_OR_USED";
                    }
                    else {
                        clients.put(p.getSocketAddress(),name);
                        send(s,p,"OK Welcome "+name);
                        broadcast(s,"JOIN "+name,p.getSocketAddress());
                        continue;
                    }
                }
                else if(x.equalsIgnoreCase("USERS")) {
                    reply="USERS "+String.join(", ",clients.values());
                }
                else if(x.startsWith("MSG ")) {
                    String name=clients.get(p.getSocketAddress());
                    if(name==null)reply="ERR SEND_NICK_FIRST";
                    else {
                        broadcast(s,"MSG "+name+": "+x.substring(4),p.getSocketAddress());
                        reply="OK SENT";
                    }
                }
                else if(x.equalsIgnoreCase("QUIT")) {
                    String name=clients.remove(p.getSocketAddress());
                    reply="BYE";
                    send(s,p,reply);
                    if(name!=null)broadcast(s,"LEFT "+name,null);
                    continue;
                }
                else reply="ERR UNKNOWN_COMMAND";
                send(s,p,reply);
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void send(DatagramSocket s,DatagramPacket p,String x)throws Exception {
        byte[] b=x.getBytes(StandardCharsets.UTF_8);
        s.send(new DatagramPacket(b,b.length,p.getAddress(),p.getPort()));
    }
    static void broadcast(DatagramSocket s,String x,SocketAddress exclude)throws Exception {
        for(SocketAddress a:clients.keySet())if(!a.equals(exclude)) {
            byte[] b=x.getBytes(StandardCharsets.UTF_8);
            InetSocketAddress z=(InetSocketAddress)a;
            s.send(new DatagramPacket(b,b.length,z.getAddress(),z.getPort()));
        }
    }
}
