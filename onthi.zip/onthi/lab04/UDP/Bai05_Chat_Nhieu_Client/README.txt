LAB 04 - BÀI 5 / UDP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  UDP port 5205

Ghi chú: Mở nhiều cửa sổ Client. Lệnh /users xem danh sách; /quit rời phòng. Với UDP, server ghi nhớ nickname theo địa chỉ IP/cổng nguồn.
