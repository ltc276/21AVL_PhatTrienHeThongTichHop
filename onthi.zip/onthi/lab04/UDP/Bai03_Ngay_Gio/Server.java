import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.time.format.*;
public class Server {
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(5203)) {
            System.out.println("UDP date/time server 5203");
            byte[] b=new byte[2048];
            while(true) {
                DatagramPacket p=new DatagramPacket(b,b.length);
                s.receive(p);
                String x=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                byte[] r=run(x).getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(r,r.length,p.getAddress(),p.getPort()));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static String run(String x) {
        try {
            DateTimeFormatter d=DateTimeFormatter.ofPattern("dd MM yyyy"),t=DateTimeFormatter.ofPattern("HH mm ss");
            LocalDateTime n=LocalDateTime.now();
            return switch(x.trim().toUpperCase()) {
                case "DATE"->d.format(n);
                case "TIME"->t.format(n);
                case "DATETIME"->d.format(n)+" "+t.format(n);
                case "QUIT"->"BYE";
                default->"ERR UNKNOWN_COMMAND";
            }
            ;
        }
        catch(Exception e) {
            return "ERR";
        }
    }
}
