import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        try(Scanner sc=new Scanner(System.in);DatagramSocket s=new DatagramSocket()) {
            s.setSoTimeout(3000);
            InetAddress host=InetAddress.getByName(a.length>0?a[0]:"localhost");
            System.out.println("DATE TIME DATETIME (QUIT chi ket thuc client)");
            while(true) {
                String x=sc.nextLine();
                byte[] b=x.getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(b,b.length,host,5203));
                byte[] r=new byte[2048];
                DatagramPacket p=new DatagramPacket(r,r.length);
                s.receive(p);
                String ans=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                System.out.println(ans);
                if(x.equalsIgnoreCase("QUIT"))break;
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
