import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket();Scanner sc=new Scanner(System.in)) {
            s.setSoTimeout(3000);
            InetAddress h=InetAddress.getByName(a.length>0?a[0]:"localhost");
            System.out.print("clientId: ");
            send(s,h,"HELLO "+sc.nextLine());
            System.out.println(recv(s));
            while(true) {
                String x=sc.nextLine();
                send(s,h,x);
                System.out.println(recv(s));
                if(x.equals("QUIT"))break;
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void send(DatagramSocket s,InetAddress h,String x)throws Exception {
        byte[] b=x.getBytes(StandardCharsets.UTF_8);
        s.send(new DatagramPacket(b,b.length,h,5207));
    }
    static String recv(DatagramSocket s)throws Exception {
        byte[] b=new byte[4096];
        DatagramPacket p=new DatagramPacket(b,b.length);
        s.receive(p);
        return new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
    }
}
