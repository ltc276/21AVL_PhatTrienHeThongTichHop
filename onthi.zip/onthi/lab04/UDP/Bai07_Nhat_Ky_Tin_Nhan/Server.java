import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.Instant;
import java.util.concurrent.*;
public class Server {
    static final int PORT=5207;
    static final ConcurrentMap<SocketAddress,String> ids=new ConcurrentHashMap<>();
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(PORT)) {
            System.out.println("Log server UDP "+PORT);
            byte[] buf=new byte[4096];
            while(true) {
                DatagramPacket p=new DatagramPacket(buf,buf.length);
                s.receive(p);
                String x=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                String ans;
                try {
                    if(x.startsWith("HELLO ")) {
                        String id=x.substring(6).trim();
                        if(!id.matches("[A-Za-z0-9_-]+"))ans="ERR INVALID_CLIENT_ID";
                        else {
                            ids.put(p.getSocketAddress(),id);
                            ans="OK";
                        }
                    }
                    else if(x.equals("QUIT")) {
                        ids.remove(p.getSocketAddress());
                        ans="BYE";
                    }
                    else {
                        String id=ids.get(p.getSocketAddress());
                        if(id==null)ans="ERR HELLO_REQUIRED";
                        else {
                            Files.createDirectories(Path.of("data","logs"));
                            String log=Instant.now()+" | "+p.getSocketAddress()+" | "+x+System.lineSeparator();
                            Files.writeString(Path.of("data","logs",id+".txt"),log,StandardCharsets.UTF_8,StandardOpenOption.CREATE,StandardOpenOption.APPEND);
                            ans="SAVED";
                        }
                    }
                }
                catch(Exception e) {
                    ans="ERR "+e.getMessage();
                }
                byte[] r=ans.getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(r,r.length,p.getAddress(),p.getPort()));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
