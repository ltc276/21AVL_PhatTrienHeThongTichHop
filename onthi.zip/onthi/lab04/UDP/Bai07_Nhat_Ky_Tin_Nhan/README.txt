LAB 04 - BÀI 7 / UDP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  UDP port 5207

Ghi chú: Sau khi gửi HELLO clientId, mỗi dòng được append vào data/logs/clientId.txt cùng timestamp và địa chỉ remote; QUIT kết thúc.
