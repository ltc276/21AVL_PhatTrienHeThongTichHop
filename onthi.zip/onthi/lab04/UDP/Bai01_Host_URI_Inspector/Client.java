import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
public class Client {
    public static void main(String[]a) {
        String server=a.length>0?a[0]:"localhost";
        try(Scanner sc=new Scanner(System.in);DatagramSocket s=new DatagramSocket()) {
            System.out.print("Hostname can tra: ");
            String host=sc.nextLine();
            System.out.print("URI can phan tich: ");
            String uri=sc.nextLine();
            byte[] b=(host+"\t"+uri).getBytes(StandardCharsets.UTF_8);
            s.send(new DatagramPacket(b,b.length,InetAddress.getByName(server),5201));
            byte[] r=new byte[8192];
            DatagramPacket p=new DatagramPacket(r,r.length);
            s.setSoTimeout(3000);
            s.receive(p);
            System.out.println(new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8));
        }
        catch(Exception e) {
            System.err.println("Loi/timeout UDP: "+e.getMessage());
        }
    }
}
