LAB 04 - BÀI 1 / UDP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  UDP port 5201

Ghi chú: Nhập hostname (ví dụ localhost) và URI (ví dụ https://example.com/a?q=1#top). In IPv4/IPv6, loopback/site-local và các thành phần URI. Với TCP cần đổi localhost thành IP server nếu chạy máy khác.
