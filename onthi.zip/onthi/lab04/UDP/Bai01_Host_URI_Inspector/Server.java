import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    static final int PORT=5201;
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(PORT)) {
            System.out.println("UDP Host/URI server port "+PORT);
            byte[] b=new byte[8192];
            while(true) {
                DatagramPacket p=new DatagramPacket(b,b.length);
                s.receive(p);
                String r=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                byte[] out=inspect(r).getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(out,out.length,p.getAddress(),p.getPort()));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static String inspect(String req) {
        try {
            String[] p=req.split("\\t",2);
            if(p.length!=2)return "ERR FORMAT";
            StringBuilder b=new StringBuilder("HOST "+p[0]);
            for(InetAddress ip:InetAddress.getAllByName(p[0]))b.append(" | IP=").append(ip.getHostAddress()).append(" type=").append(ip instanceof Inet4Address?"IPv4":"IPv6").append(" loopback=").append(ip.isLoopbackAddress()).append(" siteLocal=").append(ip.isSiteLocalAddress());
            URI u=new URI(p[1]);
            b.append(" | URI scheme=").append(u.getScheme()).append(" host=").append(u.getHost()).append(" port=").append(u.getPort()).append(" path=").append(u.getPath()).append(" query=").append(u.getQuery()).append(" fragment=").append(u.getFragment());
            return b.toString();
        }
        catch(Exception e) {
            return "ERR "+e.getClass().getSimpleName()+": "+e.getMessage();
        }
    }
}
