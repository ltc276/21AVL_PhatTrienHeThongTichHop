LAB 04 - BÀI 4 / UDP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  UDP port 5204

Ghi chú: Gửi CALC + 100 200, CALC / 10 0, CALC % 10 3, CALC + a 2 và một yêu cầu sai định dạng để quan sát ERR.
