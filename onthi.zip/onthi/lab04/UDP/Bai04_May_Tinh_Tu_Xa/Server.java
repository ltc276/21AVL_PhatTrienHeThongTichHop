import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(5204)) {
            System.out.println("UDP calculator 5204");
            byte[] b=new byte[2048];
            while(true) {
                DatagramPacket p=new DatagramPacket(b,b.length);
                s.receive(p);
                String x=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                byte[] r=calc(x).getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(r,r.length,p.getAddress(),p.getPort()));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static String calc(String req) {
        if(req.trim().equalsIgnoreCase("QUIT"))return "BYE";
        try {
            String[] p=req.trim().split("\\s+");
            if(p.length!=4||!p[0].equalsIgnoreCase("CALC"))return "ERR INVALID_FORMAT";
            double x=Double.parseDouble(p[2]),y=Double.parseDouble(p[3]);
            double r=switch(p[1]) {
                case "+"->x+y;
                case "-"->x-y;
                case "*"->x*y;
                case "/"-> {
                    if(y==0)throw new ArithmeticException("DIVIDE_BY_ZERO");
                    yield x/y;
                }
                default->throw new UnsupportedOperationException("UNSUPPORTED_OPERATOR");
            }
            ;
            return "OK "+r;
        }
        catch(ArithmeticException e) {
            return "ERR DIVIDE_BY_ZERO";
        }
        catch(UnsupportedOperationException e) {
            return "ERR UNSUPPORTED_OPERATOR";
        }
        catch(NumberFormatException e) {
            return "ERR INVALID_NUMBER";
        }
        catch(Exception e) {
            return "ERR INVALID_FORMAT";
        }
    }
}
