import java.io.ByteArrayOutputStream;
import java.net.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HexFormat;

public class Server {
    static final int PORT = 5208, CHUNK = 900;
    static String sha(byte[] data) throws Exception { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data)); }
    static void send(DatagramSocket s, InetAddress host, int port, String text) throws Exception {
        byte[] data = text.getBytes(StandardCharsets.UTF_8);
        s.send(new DatagramPacket(data, data.length, host, port));
    }
    public static void main(String[] args) {
        try (DatagramSocket socket = new DatagramSocket(PORT)) {
            socket.setSoTimeout(10000);
            System.out.println("UDP file receiver port 5208 (file toi da 1 MiB)");
            while (true) {
                DatagramPacket meta = new DatagramPacket(new byte[4096], 4096);
                try { socket.receive(meta); } catch (SocketTimeoutException e) { continue; }
                String[] fields = new String(meta.getData(), meta.getOffset(), meta.getLength(), StandardCharsets.UTF_8).split("\\|", -1);
                if (fields.length != 5 || !fields[0].equals("META")) { send(socket, meta.getAddress(), meta.getPort(), "ERR METADATA"); continue; }
                String name = fields[1], expectedHash = fields[3];
                int size, count;
                try { size = Integer.parseInt(fields[2]); count = Integer.parseInt(fields[4]); }
                catch (NumberFormatException e) { send(socket, meta.getAddress(), meta.getPort(), "ERR METADATA"); continue; }
                if (!name.matches("[A-Za-z0-9._-]+") || name.contains("..") || size < 0 || size > 1_048_576 || count != (size + CHUNK - 1) / CHUNK) {
                    send(socket, meta.getAddress(), meta.getPort(), "ERR INVALID_METADATA"); continue;
                }
                send(socket, meta.getAddress(), meta.getPort(), "READY");
                ByteArrayOutputStream data = new ByteArrayOutputStream();
                int expected = 0;
                while (expected < count) {
                    DatagramPacket packet = new DatagramPacket(new byte[CHUNK + 16], CHUNK + 16);
                    try { socket.receive(packet); } catch (SocketTimeoutException e) { send(socket, meta.getAddress(), meta.getPort(), "ERR TIMEOUT"); expected = -1; break; }
                    if (!packet.getAddress().equals(meta.getAddress()) || packet.getPort() != meta.getPort()) continue;
                    byte[] raw = Arrays.copyOfRange(packet.getData(), packet.getOffset(), packet.getOffset() + packet.getLength());
                    if (raw.length < 4) continue;
                    int index = ByteBuffer.wrap(raw, 0, 4).getInt();
                    if (index == expected) { data.write(raw, 4, raw.length - 4); expected++; send(socket, meta.getAddress(), meta.getPort(), "ACK " + index); }
                    else if (index < expected) send(socket, meta.getAddress(), meta.getPort(), "ACK " + index);
                    else send(socket, meta.getAddress(), meta.getPort(), "NACK " + expected);
                }
                if (expected < 0) continue;
                byte[] all = data.toByteArray();
                String result;
                if (all.length != size) result = "ERR SIZE_MISMATCH";
                else if (!sha(all).equalsIgnoreCase(expectedHash)) result = "ERR HASH_MISMATCH";
                else { Files.createDirectories(Path.of("upload")); Files.write(Path.of("upload", name), all); result = "OK SHA256=" + sha(all) + " SIZE=" + size; }
                send(socket, meta.getAddress(), meta.getPort(), result);
                System.out.println(name + ": " + result);
            }
        } catch (Exception e) { System.err.println("UDP file server: " + e.getMessage()); }
    }
}
