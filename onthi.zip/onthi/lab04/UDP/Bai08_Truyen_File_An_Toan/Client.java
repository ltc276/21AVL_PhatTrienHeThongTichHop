import java.net.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;
public class Client {
    static final int PORT=5208,CHUNK=900;
    static String sha(byte[] b)throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b));
    }
    static String ask(DatagramSocket s,InetAddress h,byte[] data)throws Exception {
        s.send(new DatagramPacket(data,data.length,h,PORT));
        byte[] b=new byte[2048];
        DatagramPacket p=new DatagramPacket(b,b.length);
        s.receive(p);
        return new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
    }
    public static void main(String[]a) {
        if(a.length<1) {
            System.out.println("Cach dung: java Client <file> [server-ip]");
            return;
        }
        try(DatagramSocket s=new DatagramSocket()) {
            s.setSoTimeout(2500);
            Path f=Path.of(a[0]);
            byte[] data=Files.readAllBytes(f);
            if(data.length>1_048_576)throw new IllegalArgumentException("UDP demo gioi han 1 MiB");
            InetAddress h=InetAddress.getByName(a.length>1?a[1]:"localhost");
            String name=f.getFileName().toString();
            if(!name.matches("[A-Za-z0-9._-]+")||name.contains(".."))throw new IllegalArgumentException("Ten file chi duoc chu/so/._- va khong duoc co ..");
            int count=(data.length+CHUNK-1)/CHUNK;
            String meta="META|"+name+"|"+data.length+"|"+sha(data)+"|"+count;
            String r=ask(s,h,meta.getBytes(StandardCharsets.UTF_8));
            if(!r.equals("READY"))throw new IOExceptionLike(r);
            for(int i=0;i<count;i++) {
                int start=i*CHUNK,len=Math.min(CHUNK,data.length-start);
                byte[] packet=ByteBuffer.allocate(4+len).putInt(i).put(data,start,len).array();
                boolean ack=false;
                for(int tries=0;tries<5&&!ack;tries++) {
                    s.send(new DatagramPacket(packet,packet.length,h,PORT));
                    byte[] b=new byte[128];
                    DatagramPacket p=new DatagramPacket(b,b.length);
                    try {
                        s.receive(p);
                        String ans=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                        ack=ans.equals("ACK "+i);
                    }
                    catch(SocketTimeoutException e) {
                    }
                }
                if(!ack)throw new SocketTimeoutException("Khong nhan ACK chunk "+i);
            }
            byte[] finalBuf=new byte[2048];
            DatagramPacket finalPacket=new DatagramPacket(finalBuf,finalBuf.length);
            s.receive(finalPacket);
            System.out.println(new String(finalPacket.getData(),finalPacket.getOffset(),finalPacket.getLength(),StandardCharsets.UTF_8));
        }
        catch(Exception e) {
            System.err.println("UDP transfer that bai: "+e.getMessage());
        }
    }
    static class IOExceptionLike extends Exception {
        IOExceptionLike(String s) {
            super(s);
        }
    }
}
