import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Enumeration;
public class Server {
    static final String GROUP="239.255.0.1";
    static final int PORT=5209;
    public static void main(String[]a) {
        try {
            InetAddress group=InetAddress.getByName(GROUP);
            NetworkInterface ni=null;
            Enumeration<NetworkInterface> all=NetworkInterface.getNetworkInterfaces();
            while(all.hasMoreElements()) {
                NetworkInterface x=all.nextElement();
                try {
                    if(x.isUp()&&!x.isLoopback()&&x.supportsMulticast()) {
                        ni=x;
                        break;
                    }
                }
                catch(Exception ignored) {
                }
            }
            if(ni==null)throw new IllegalStateException("Khong tim thay card mang ho tro multicast; kiem tra Wi-Fi/VPN/firewall");
            try(MulticastSocket s=new MulticastSocket(null)) {
                s.setReuseAddress(true);
                s.bind(new InetSocketAddress(PORT));
                s.joinGroup(new InetSocketAddress(group,PORT),ni);
                System.out.println("Receiver multicast group="+GROUP+" port="+PORT+" interface="+ni.getName());
                byte[] b=new byte[4096];
                while(true) {
                    DatagramPacket p=new DatagramPacket(b,b.length);
                    s.receive(p);
                    System.out.println(new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8));
                }
            }
        }
        catch(Exception e) {
            System.err.println("Multicast receiver loi: "+e.getMessage());
        }
    }
}
