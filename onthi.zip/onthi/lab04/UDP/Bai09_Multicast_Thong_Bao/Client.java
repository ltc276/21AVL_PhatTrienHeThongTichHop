import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import java.util.Enumeration;
public class Client {
    public static void main(String[]a) {
        try(MulticastSocket s=new MulticastSocket();Scanner sc=new Scanner(System.in)) {
            s.setBroadcast(false);
            NetworkInterface ni=null;
            Enumeration<NetworkInterface> all=NetworkInterface.getNetworkInterfaces();
            while(all.hasMoreElements()) {
                NetworkInterface x=all.nextElement();
                try {
                    if(x.isUp()&&!x.isLoopback()&&x.supportsMulticast()) {
                        ni=x;
                        break;
                    }
                }
                catch(Exception ignored) {
                }
            }
            if(ni!=null)s.setNetworkInterface(ni);
            InetAddress group=InetAddress.getByName("239.255.0.1");
            System.out.println("Nhap thong bao multicast; QUIT de dung. Can chay Server o it nhat mot receiver.");
            while(true) {
                String x=sc.nextLine();
                if(x.equals("QUIT"))break;
                byte[] b=x.getBytes(StandardCharsets.UTF_8);
                s.send(new DatagramPacket(b,b.length,group,5209));
            }
        }
        catch(Exception e) {
            System.err.println("Multicast send loi: "+e.getMessage());
        }
    }
}
