LAB 04 - BÀI 9 / UDP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client

Giao thức/cảng:
  UDP port 5209

Ghi chú: Mở java Server ở tối thiểu hai cửa sổ receiver; cửa sổ Client phát multicast. TCP không hỗ trợ multicast nên phiên bản TCP dùng server trung tâm chuyển tiếp tin tới các client đã kết nối.
