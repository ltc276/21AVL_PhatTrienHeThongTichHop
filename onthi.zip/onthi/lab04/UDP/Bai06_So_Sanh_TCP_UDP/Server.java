import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    public static void main(String[]a) {
        try(DatagramSocket s=new DatagramSocket(5206)) {
            System.out.println("UDP benchmark server 5206");
            byte[] b=new byte[2048];
            while(true) {
                DatagramPacket p=new DatagramPacket(b,b.length);
                s.receive(p);
                s.send(new DatagramPacket(p.getData(),p.getOffset(),p.getLength(),p.getAddress(),p.getPort()));
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
