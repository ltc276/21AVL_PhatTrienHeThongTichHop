import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

public class Client {
    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        try (DatagramSocket socket = new DatagramSocket()) {
            socket.setSoTimeout(100);
            InetAddress address = InetAddress.getByName(host);
            for (int round = 1; round <= 5; round++) {
                long start = System.nanoTime();
                Set<Integer> seen = ConcurrentHashMap.newKeySet();
                AtomicBoolean sendingDone = new AtomicBoolean(false);
                Thread receiver = new Thread(() -> {
                    long deadline = Long.MAX_VALUE;
                    while (!sendingDone.get() || (seen.size() < 1000 && System.nanoTime() < deadline)) {
                        if (sendingDone.get() && deadline == Long.MAX_VALUE) deadline = System.nanoTime() + 2_000_000_000L;
                        try {
                            byte[] buf = new byte[2048];
                            DatagramPacket packet = new DatagramPacket(buf, buf.length);
                            socket.receive(packet);
                            String reply = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
                            if (reply.startsWith("PING-")) {
                                int end = reply.indexOf('-', 5);
                                if (end > 5) {
                                    try { int id = Integer.parseInt(reply.substring(5, end)); if (id >= 0 && id < 1000) seen.add(id); }
                                    catch (NumberFormatException ignored) { }
                                }
                            }
                        } catch (SocketTimeoutException ignored) { }
                        catch (Exception e) { break; }
                    }
                });
                receiver.start();
                for (int i = 0; i < 1000; i++) {
                    byte[] data = ("PING-" + i + "-XXXXXXXXXXXXXXXX").getBytes(StandardCharsets.UTF_8);
                    socket.send(new DatagramPacket(data, data.length, address, 5206));
                    if ((i + 1) % 10 == 0) Thread.sleep(1); // Nhip nho giup khong tran bo dem UDP qua nhanh.
                }
                sendingDone.set(true);
                receiver.join(2500);
                System.out.printf("Lan %d: phan hoi hop le %d/1000, %.2f ms%n", round, seen.size(), (System.nanoTime() - start) / 1_000_000.0);
            }
        } catch (Exception e) { System.err.println("Benchmark UDP: " + e.getMessage()); }
    }
}
