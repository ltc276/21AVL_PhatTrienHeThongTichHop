LAB 04 - BÀI 10 / UDP

Biên dịch trong thư mục này:
  javac Server.java Client.java

Terminal 1 (giữ chạy):
  java Server

Terminal 2:
  java Client localhost

Giao thức/cảng:
  UDP port 5210 (dịch vụ TCP phụ 5211)

Ghi chú: Server đồng thời lắng nghe UDP 5210 để trả lời DISCOVER_SERVICE và TCP 5211 cho dịch vụ thật; dùng localhost để kiểm thử một máy, hoặc IPv4 server khi ở LAN.
