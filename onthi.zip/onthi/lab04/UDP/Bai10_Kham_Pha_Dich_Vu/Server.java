import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
public class Server {
    static final int DISCOVERY=5210,TCP_PORT=5211;
    public static void main(String[]a) {
        Thread udp=new Thread(()->discover());
        udp.setDaemon(true);
        udp.start();
        try(ServerSocket ss=new ServerSocket(TCP_PORT)) {
            System.out.println("Service TCP port "+TCP_PORT+"; UDP discovery port "+DISCOVERY);
            while(true) {
                Socket s=ss.accept();
                new Thread(()-> {
                    try(s;BufferedReader in=new BufferedReader(new InputStreamReader(s.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),StandardCharsets.UTF_8),true)) {
                        out.println("SERVICE DemoService "+TCP_PORT+" v1");out.println("OK "+in.readLine());
                    }
                    catch(Exception ignored) {
                    }
                }
                ).start();
            }
        }
        catch(Exception e) {
            System.err.println(e.getMessage());
        }
    }
    static void discover() {
        try(DatagramSocket s=new DatagramSocket(DISCOVERY)) {
            byte[] b=new byte[1024];
            while(true) {
                DatagramPacket p=new DatagramPacket(b,b.length);
                s.receive(p);
                String x=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                if(x.equals("DISCOVER_SERVICE")) {
                    byte[] r=("SERVICE DemoService "+TCP_PORT+" v1").getBytes(StandardCharsets.UTF_8);
                    s.send(new DatagramPacket(r,r.length,p.getAddress(),p.getPort()));
                }
            }
        }
        catch(Exception e) {
            System.err.println("Discovery UDP: "+e.getMessage());
        }
    }
}
