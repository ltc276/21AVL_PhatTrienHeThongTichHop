import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
public class Client {
    public static void main(String[]a) {
        String host=a.length>0?a[0]:"127.0.0.1";
        try(DatagramSocket udp=new DatagramSocket()) {
            udp.setSoTimeout(700);
            InetAddress dest=InetAddress.getByName(host);
            byte[] req="DISCOVER_SERVICE".getBytes(StandardCharsets.UTF_8);
            udp.send(new DatagramPacket(req,req.length,dest,5210));
            Map<String,String> seen=new LinkedHashMap<>();
            long end=System.currentTimeMillis()+700;
            do {
                try {
                    byte[] b=new byte[1024];
                    DatagramPacket p=new DatagramPacket(b,b.length);
                    udp.receive(p);
                    String r=new String(p.getData(),p.getOffset(),p.getLength(),StandardCharsets.UTF_8);
                    seen.put(p.getAddress().getHostAddress()+"|"+r,p.getAddress().getHostAddress()+"|"+r);
                }
                catch(SocketTimeoutException e) {
                    break;
                }
            }
            while(System.currentTimeMillis()<end);
            if(seen.isEmpty()) {
                System.out.println("Khong tim thay service (timeout)");
                return;
            }
            String first=seen.values().iterator().next();
            System.out.println("Servers tim thay: "+seen.values());
            String[] parts=first.split("\\|",2);
            String address=parts[0],service=parts[1];
            String[] tokens=service.split("\\s+");
            int port=Integer.parseInt(tokens[2]);
            try(Socket tcp=new Socket(address,port);BufferedReader in=new BufferedReader(new InputStreamReader(tcp.getInputStream(),StandardCharsets.UTF_8));PrintWriter out=new PrintWriter(new OutputStreamWriter(tcp.getOutputStream(),StandardCharsets.UTF_8),true)) {
                System.out.println("TCP: "+in.readLine());
                out.println("PING");
                System.out.println(in.readLine());
            }
        }
        catch(Exception e) {
            System.err.println("Discovery/client loi: "+e.getMessage());
        }
    }
}
