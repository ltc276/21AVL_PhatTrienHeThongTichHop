import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Server {
    private static final int PORT = 7000;
    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("TCP Server dang lang nghe cong " + PORT);
            while (true) {
                Socket socket = server.accept();
                new Thread(() -> xuLyClient(socket)).start(); // Moi client duoc xu ly tren mot thread rieng.
            }
        } catch (IOException e) { System.err.println("Loi server: " + e.getMessage()); }
    }
    private static void xuLyClient(Socket socket) {
        try (socket;
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.UTF_8)) {
            out.println("Nhap STT sinh vien:");
            String stt = in.readLine();
            if (stt == null || !stt.matches("\\d+")) { out.println("ERR STT khong hop le"); return; }
            boolean chan = Long.parseLong(stt) % 2 == 0;
            out.println(chan ? "SERVICES: 2,4" : "SERVICES: 1,3");
            out.println("Nhap so dich vu:");
            String chon = in.readLine();
            int dichVu;
            try { dichVu = Integer.parseInt(chon); } catch (Exception e) { out.println("ERR Dich vu khong hop le"); return; }
            if ((chan && dichVu != 2 && dichVu != 4) || (!chan && dichVu != 1 && dichVu != 3)) {
                out.println("ERR STT nay khong duoc chon dich vu " + dichVu); return;
            }
            out.println("READY Nhap cac dong, dong ket thuc la dau cham .");
            List<String> dong = new ArrayList<>();
            String line;
            while ((line = in.readLine()) != null && !line.equals(".")) dong.add(line);
            if (line == null) return;
            out.println("RESULT " + xuLy(dichVu, dong));
            String ketThuc = in.readLine();
            if ("EXIT.".equals(ketThuc)) out.println("BYE");
            else out.println("ERR Hay gui EXIT. de dong ket noi");
        } catch (IOException e) { System.err.println("Loi client: " + e.getMessage()); }
    }
    private static String vietHoaDauMoiTu(String text) {
        String[] words = text.toLowerCase(Locale.ROOT).split("\s+");
        StringBuilder sb = new StringBuilder();
        for (String word : words) {
            if (word.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(word.charAt(0))).append(word.substring(1));
        }
        return sb.toString();
    }
    private static String xuLy(int dichVu, List<String> dong) {
        String noiDung = String.join(" ", dong).trim();
        if (dichVu == 1) return vietHoaDauMoiTu(new StringBuilder(noiDung).reverse().toString());
        if (dichVu == 2) {
            String[] words = noiDung.split("\s+");
            for (int i=0;i<words.length;i++) words[i] = new StringBuilder(words[i]).reverse().toString();
            return vietHoaDauMoiTu(String.join(" ", words));
        }
        if (dichVu == 3) {
            int count = 0;
            for (String s : dong) { String t = s.trim(); if (!t.isEmpty()) count += t.split("\s+").length; }
            return "So tu = " + count;
        }
        return "So dong = " + dong.size();
    }
}
