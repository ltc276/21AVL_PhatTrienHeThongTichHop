import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        int port = args.length > 1 ? Integer.parseInt(args[1]) : 7000;
        try (Socket socket = new Socket(host, port);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true, StandardCharsets.UTF_8);
             Scanner sc = new Scanner(System.in)) {
            System.out.println(in.readLine());
            System.out.print("STT: "); out.println(sc.nextLine());
            String menu = in.readLine(); System.out.println(menu);
            if (menu.startsWith("ERR")) return;
            System.out.println(in.readLine());
            System.out.print("Chon dich vu: "); out.println(sc.nextLine());
            String ready = in.readLine(); System.out.println(ready);
            if (ready.startsWith("ERR")) return;
            while (true) {
                String line = sc.nextLine(); out.println(line);
                if (line.equals(".")) break;
            }
            System.out.println(in.readLine());
            out.println("EXIT.");
            System.out.println(in.readLine());
        } catch (Exception e) { System.err.println("Loi client: " + e.getMessage()); }
    }
}
