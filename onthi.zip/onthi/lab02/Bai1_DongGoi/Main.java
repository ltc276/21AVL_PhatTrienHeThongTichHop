public class Main {
    public static void main(String[] args) {
        SanPham p1=new SanPham("SP01","Ban phim",350000,10);
        SanPham p2=new SanPham("SP02","Chuot",250000,5);
        System.out.println("Ban dau:");p1.hienThiThongTin();p2.hienThiThongTin();
        p1.nhapHang(4);System.out.println("Sau khi nhap them 4:");p1.hienThiThongTin();
        System.out.println("Ban 3 san pham: "+p1.banHang(3));p1.hienThiThongTin();
        System.out.println("Thu ban qua ton kho: "+p2.banHang(20));p2.hienThiThongTin();
    }
}
