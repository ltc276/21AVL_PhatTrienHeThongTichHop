public class SanPham {
    private String maSP, tenSP;
    private double donGia;
    private int soLuong;
    public SanPham(String maSP, String tenSP, double donGia, int soLuong) {
        if (maSP == null || maSP.isBlank() || tenSP == null || tenSP.isBlank()) throw new IllegalArgumentException("Ma va ten khong duoc rong");
        if (donGia <= 0 || soLuong < 0) throw new IllegalArgumentException("Don gia phai > 0, so luong >= 0");
        this.maSP=maSP;this.tenSP=tenSP;this.donGia=donGia;this.soLuong=soLuong;
    }
    public String getMaSP(){return maSP;} public String getTenSP(){return tenSP;}
    public double getDonGia(){return donGia;} public int getSoLuong(){return soLuong;}
    public void setTenSP(String v){if(v==null||v.isBlank())throw new IllegalArgumentException("Ten rong");tenSP=v;}
    public void setDonGia(double v){if(v<=0)throw new IllegalArgumentException("Don gia phai > 0");donGia=v;}
    public double tinhThanhTien(){return donGia*soLuong;}
    public void nhapHang(int soLuongNhap){if(soLuongNhap<=0)throw new IllegalArgumentException("So luong nhap phai > 0");soLuong+=soLuongNhap;}
    public boolean banHang(int soLuongBan){if(soLuongBan<=0||soLuongBan>soLuong)return false;soLuong-=soLuongBan;return true;}
    public void hienThiThongTin(){System.out.printf("%s | %s | don gia %.0f | ton kho %d | thanh tien %.0f%n",maSP,tenSP,donGia,soLuong,tinhThanhTien());}
}
