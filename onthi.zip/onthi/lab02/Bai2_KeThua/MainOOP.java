public class MainOOP {
    public static void main(String[] args) {
        SinhVien sv1=new SinhVien("Le Tan Cuong",2005,"TP HCM","25000901","CNTT",8.7);
        SinhVien sv2=new SinhVien("Nguyen Van A",2004,"Dong Nai","25000902","Mang may tinh",6.8);
        GiangVien gv1=new GiangVien("Tran Thi B",1985,"TP HCM","GV01","Java",12000000,2.5);
        GiangVien gv2=new GiangVien("Pham Van C",1980,"Binh Duong","GV02","Mang",15000000,2.1);
        System.out.println("=== SINH VIEN ===");sv1.hienThiThongTin();sv2.hienThiThongTin();
        System.out.println("=== GIANG VIEN ===");gv1.hienThiThongTin();gv2.hienThiThongTin();
    }
}
