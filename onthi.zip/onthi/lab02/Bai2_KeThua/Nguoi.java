import java.time.Year;

public class Nguoi {
    private String hoTen, diaChi;
    private int namSinh;
    public Nguoi(String hoTen,int namSinh,String diaChi){this.hoTen=hoTen;this.namSinh=namSinh;this.diaChi=diaChi;}
    public String getHoTen(){return hoTen;} public void setHoTen(String v){hoTen=v;}
    public int getNamSinh(){return namSinh;} public void setNamSinh(int v){namSinh=v;}
    public String getDiaChi(){return diaChi;} public void setDiaChi(String v){diaChi=v;}
    public int tinhTuoi(){return Year.now().getValue()-namSinh;}
    public void hienThiThongTin(){System.out.println("Ho ten: "+hoTen+", nam sinh: "+namSinh+", tuoi: "+tinhTuoi()+", dia chi: "+diaChi);}
}
