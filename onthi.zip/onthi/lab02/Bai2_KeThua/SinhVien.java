public class SinhVien extends Nguoi {
    private String maSinhVien, nganhHoc;
    private double diemTrungBinh;
    public SinhVien(String hoTen,int namSinh,String diaChi,String maSinhVien,String nganhHoc,double diemTrungBinh){super(hoTen,namSinh,diaChi);this.maSinhVien=maSinhVien;this.nganhHoc=nganhHoc;setDiemTrungBinh(diemTrungBinh);}
    public String getMaSinhVien(){return maSinhVien;} public void setMaSinhVien(String v){maSinhVien=v;}
    public String getNganhHoc(){return nganhHoc;} public void setNganhHoc(String v){nganhHoc=v;}
    public double getDiemTrungBinh(){return diemTrungBinh;} public void setDiemTrungBinh(double v){if(v<0||v>10)throw new IllegalArgumentException("Diem phai 0..10");diemTrungBinh=v;}
    public String xepLoai(){if(diemTrungBinh>=8.5)return "Gioi";if(diemTrungBinh>=7)return "Kha";if(diemTrungBinh>=5)return "Trung binh";return "Yeu";}
    @Override public void hienThiThongTin(){super.hienThiThongTin();System.out.println("Sinh vien: "+maSinhVien+", nganh: "+nganhHoc+", diem TB: "+diemTrungBinh+", xep loai: "+xepLoai());}
}
