public class GiangVien extends Nguoi {
    private String maGiangVien, chuyenMon;
    private double luongCoBan, heSoLuong;
    public GiangVien(String hoTen,int namSinh,String diaChi,String maGiangVien,String chuyenMon,double luongCoBan,double heSoLuong) {
        super(hoTen,namSinh,diaChi);
        this.maGiangVien=maGiangVien;
        this.chuyenMon=chuyenMon;
        this.luongCoBan=luongCoBan;
        this.heSoLuong=heSoLuong;
    }
    public String getMaGiangVien() {
        return maGiangVien;
    }
    public void setMaGiangVien(String v) {
        maGiangVien=v;
    }
    public String getChuyenMon() {
        return chuyenMon;
    }
    public void setChuyenMon(String v) {
        chuyenMon=v;
    }
    public double getLuongCoBan() {
        return luongCoBan;
    }
    public void setLuongCoBan(double v) {
        if(v<0)throw new IllegalArgumentException("Luong co ban khong hop le");
        luongCoBan=v;
    }
    public double getHeSoLuong() {
        return heSoLuong;
    }
    public void setHeSoLuong(double v) {
        if(v<0)throw new IllegalArgumentException("He so luong khong hop le");
        heSoLuong=v;
    }
    public double tinhLuong() {
        return luongCoBan*heSoLuong;
    }
    @Override public void hienThiThongTin() {
        super.hienThiThongTin();
        System.out.printf("Giang vien: %s, chuyen mon: %s, luong: %.0f%n",maGiangVien,chuyenMon,tinhLuong());
    }
}
