ONTHI JAVA - MÃ NGUỒN VÀ TÀI LIỆU ÔN TẬP

Cấu trúc gồm kt_thu, lab01, lab01b, lab02, lab03, lab04.
Mỗi thư mục có file HUONG_DAN.txt, mô tả luồng chương trình, lệnh chạy và tư duy cần nhớ.

YÊU CẦU MÔI TRƯỜNG
- Cài JDK 17 trở lên (Lab 04 dùng API hiện đại của Java).
- Mở CMD/PowerShell tại đúng thư mục chứa file .java.
- Biên dịch: javac TenFile.java (hoặc javac *.java nếu hướng dẫn ghi như vậy).
- Chạy: java TenLop (không thêm đuôi .java).
- Chạy client/server: luôn chạy Server trước, rồi mở cửa sổ terminal khác chạy Client.
- Khi chạy mạng trên hai máy, thay localhost bằng IPv4 của máy chạy server và cho phép đúng cổng qua firewall.

LƯU Ý
- Mỗi bài con trong lab04 là chương trình độc lập; không biên dịch tất cả bài vào một thư mục chung.
- Những ví dụ xóa file/thư mục chỉ thao tác với đường dẫn do người dùng truyền vào. Hãy thử trên dữ liệu mẫu, không dùng đường dẫn hệ thống.
- TCP có kết nối và bảo đảm thứ tự; UDP gửi datagram không bảo đảm đến nơi/thứ tự. Các bản TCP/UDP của từng bài được chia rõ theo yêu cầu ôn thi.
