import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class InventoryManager {
    static class Product {
        String ma, ten;
        double gia;
        int soLuong;
        Product(String ma,String ten,double gia,int soLuong) {
            if(ma.isBlank()||ten.isBlank()||gia<=0||soLuong<0)throw new IllegalArgumentException("Ma/ten rong, gia <= 0 hoac so luong am");
            this.ma=ma;
            this.ten=ten;
            this.gia=gia;
            this.soLuong=soLuong;
        }
        double thanhTien() {
            return gia*soLuong;
        }
        String csv() {
            return ma+","+ten+","+gia+","+soLuong;
        }
        public String toString() {
            return String.format("%s | %s | gia %.0f | SL %d | tri gia %.0f",ma,ten,gia,soLuong,thanhTien());
        }
    }
    static List<Product> docCSV(Path file)throws IOException {
        List<Product> ds=new ArrayList<>();
        List<String> lines=Files.readAllLines(file,StandardCharsets.UTF_8);
        for(int i=1;i<lines.size();i++) {
            String line=lines.get(i);
            if(line.isBlank())continue;
            String[] p=line.split(",",-1);
            if(p.length!=4) {
                System.err.println("Bo qua dong CSV "+(i+1));
                continue;
            }
            try {
                ds.add(new Product(p[0].trim(),p[1].trim(),Double.parseDouble(p[2].trim()),Integer.parseInt(p[3].trim())));
            }
            catch(RuntimeException e) {
                System.err.println("Dong "+(i+1)+" khong hop le: "+e.getMessage());
            }
        }
        return ds;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        Path data=Path.of("data","inventory.csv"), report=Path.of("data","inventory-report.txt");
        List<Product> ds=new ArrayList<>();
        try {
            Files.createDirectories(data.getParent());
            System.out.print("Nhap so san pham: ");
            int n=Integer.parseInt(sc.nextLine());
            if(n<=0)throw new IllegalArgumentException("So san pham phai > 0");
            for(int i=0;i<n;i++) {
                while(true) {
                    try {
                        System.out.println("San pham "+(i+1));
                        System.out.print("Ma: ");
                        String ma=sc.nextLine();
                        System.out.print("Ten (khong dung dau phay): ");
                        String ten=sc.nextLine();
                        System.out.print("Don gia: ");
                        double gia=Double.parseDouble(sc.nextLine());
                        System.out.print("So luong: ");
                        int sl=Integer.parseInt(sc.nextLine());
                        ds.add(new Product(ma,ten,gia,sl));
                        break;
                    }
                    catch(RuntimeException e) {
                        System.out.println("Du lieu khong hop le: "+e.getMessage()+". Nhap lai san pham nay.");
                    }
                }
            }
            List<String> lines=new ArrayList<>();
            lines.add("ma,ten,donGia,soLuong");
            for(Product p:ds)lines.add(p.csv());
            Files.write(data,lines,StandardCharsets.UTF_8);
            System.out.println("Da luu: "+data.toAbsolutePath());
            ds=docCSV(data);
            double tong=0;
            Product max=ds.get(0);
            System.out.println("DANH SACH DOC LAI:");
            for(Product p:ds) {
                System.out.println(p);
                tong+=p.thanhTien();
                if(p.thanhTien()>max.thanhTien())max=p;
            }
            List<String> baoCao=List.of("So san pham: "+ds.size(),String.format("Tong gia tri ton kho: %.0f",tong),"San pham gia tri cao nhat: "+max.ma+" - "+max.ten+" - "+String.format("%.0f",max.thanhTien()));
            Files.write(report,baoCao,StandardCharsets.UTF_8);
            System.out.println("Tong gia tri: "+tong);
            System.out.println("Cao nhat: "+max);
            System.out.println("Da ghi bao cao: "+report.toAbsolutePath());
        }
        catch(IOException|IllegalArgumentException e) {
            System.err.println("Khong the xu ly ton kho: "+e.getMessage());
        }
    }
}
