public class Product {
    private final String code, name;
    private final double unitPrice;
    private final int quantity;
    public Product(String code,String name,double unitPrice,int quantity){
        if(code==null||code.isBlank()||name==null||name.isBlank())throw new IllegalArgumentException("Ma/ten khong duoc rong");
        if(unitPrice<=0||quantity<0)throw new IllegalArgumentException("Gia phai > 0 va so luong >= 0");
        this.code=code;this.name=name;this.unitPrice=unitPrice;this.quantity=quantity;
    }
    public double inventoryValue(){return unitPrice*quantity;}
    @Override public String toString(){return String.format("%s - %s: %,.0f VND",code,name,inventoryValue());}
}
