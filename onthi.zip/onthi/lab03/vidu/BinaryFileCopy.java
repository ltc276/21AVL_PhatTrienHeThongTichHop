import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public class BinaryFileCopy {
    public static void main(String[] args) {
        if (args.length != 2) { System.out.println("Cach dung: java BinaryFileCopy <nguon> <dich>"); return; }
        Path source=Path.of(args[0]), target=Path.of(args[1]); long total=0;
        try (InputStream in=new BufferedInputStream(Files.newInputStream(source)); OutputStream out=new BufferedOutputStream(Files.newOutputStream(target))) {
            byte[] buffer=new byte[8192]; int n;
            while((n=in.read(buffer))!=-1){out.write(buffer,0,n);total+=n;}
            System.out.println("Da sao chep "+total+" byte.");
        } catch(IOException e){System.err.println("Sao chep that bai: "+e.getMessage());}
    }
}
