import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class TextFileDemo {
    public static void main(String[] args) {
        Path file = Path.of("data", "ghi_chu.txt");
        try {
            Files.createDirectories(file.getParent());
            try (BufferedWriter w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
                w.write("Java I/O làm việc với các luồng dữ liệu."); w.newLine();
                w.write("BufferedWriter giúp ghi văn bản hiệu quả."); w.newLine();
                w.write("UTF-8 hỗ trợ tiếng Việt ổn định."); w.newLine();
            }
            try (BufferedReader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
                String line; int i=1; while ((line=r.readLine())!=null) System.out.println((i++)+". "+line);
            }
        } catch (IOException e) { System.err.println("Loi tep: " + e.getMessage()); }
    }
}
