import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ProductCsvApp {
    public static void main(String[] args) {
        Path input=Path.of("data","products.csv"), report=Path.of("data","report.txt");
        List<Product> products=new ArrayList<>();
        try {
            Files.createDirectories(input.getParent());
            if(!Files.exists(input)) Files.writeString(input,"ma,ten,donGia,soLuong\nSP01,Ban phim,350000,10\nSP02,Chuot khong day,250000,5\nSP03,Tai nghe,600000,3\n",StandardCharsets.UTF_8);
            try(BufferedReader r=Files.newBufferedReader(input,StandardCharsets.UTF_8)){
                r.readLine(); String line; int no=1;
                while((line=r.readLine())!=null){no++;if(line.isBlank())continue;String[] p=line.split(",",-1);if(p.length!=4){System.err.println("Bo qua dong "+no);continue;}
                    try{products.add(new Product(p[0].trim(),p[1].trim(),Double.parseDouble(p[2].trim()),Integer.parseInt(p[3].trim())));}catch(IllegalArgumentException e){System.err.println("Dong "+no+" sai: "+e.getMessage());}
                }
            }
            double total=0;for(Product p:products){System.out.println(p);total+=p.inventoryValue();}
            try(BufferedWriter w=Files.newBufferedWriter(report,StandardCharsets.UTF_8)){w.write("So san pham: "+products.size());w.newLine();w.write(String.format("Tong gia tri ton kho: %,.0f VND",total));w.newLine();}
            System.out.println("Da ghi bao cao: "+report);
        }catch(IOException e){System.err.println("Loi I/O: "+e.getMessage());}
    }
}
