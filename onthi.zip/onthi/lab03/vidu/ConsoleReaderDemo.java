import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class ConsoleReaderDemo {
    public static void main(String[] args) {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
        int count = 0;
        System.out.println("Nhap tung dong; nhap q de dung:");
        try {
            while (true) {
                String line = reader.readLine();
                if (line == null || line.equalsIgnoreCase("q")) break;
                count++;
                System.out.println("Dong " + count + ": " + line);
            }
        } catch (IOException e) { System.err.println("Khong doc duoc: " + e.getMessage()); }
        System.out.println("Tong so dong: " + count);
    }
}
