import java.nio.file.Files;
import java.nio.file.Path;

public class DeleteFolderDemo {
    private static void xoaDeQuy(Path p) throws Exception {
        if (Files.isDirectory(p)) {
            try (var ds = Files.list(p)) {
                for (Path con : ds.toList()) xoaDeQuy(con);
            }
        }
        Files.deleteIfExists(p);
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Cach dung: java DeleteFolderDemo <thu-muc-thu-nghiem>");
            return;
        }
        Path p = Path.of(args[0]).toAbsolutePath().normalize();
        if (!Files.isDirectory(p)) {
            System.out.println("Thu muc khong ton tai");
            return;
        }
        System.out.println("Se xoa vinh vien: " + p);
        System.out.print("Nhap YES de xac nhan: ");
        if (new java.util.Scanner(System.in).nextLine().equals("YES")) {
            xoaDeQuy(p);
            System.out.println("Da xoa thu muc");
        } else System.out.println("Da huy");
    }
}
