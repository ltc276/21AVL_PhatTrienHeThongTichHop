import java.util.Scanner;

public class ThangTiengAnh {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] thang = {"January", "February", "March", "April", "May", "June",
                          "July", "August", "September", "October", "November", "December"};
        while (true) {
            System.out.print("Nhap thang 1-12 (so khac de dung): ");
            int n = sc.nextInt();
            if (n < 1 || n > 12) break;
            System.out.println(thang[n - 1]);
        }
        System.out.println("STOP");
    }
}
