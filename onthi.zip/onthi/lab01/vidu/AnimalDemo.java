abstract class Animal {
    protected String name;
    protected double weight;
    Animal(String name, double weight) { this.name = name; this.weight = weight; }
    abstract void hienThi();
}

class Lion extends Animal {
    private double eat;
    Lion(String name, double weight, double eat) { super(name, weight); this.eat = eat; }
    void hienThi() { System.out.println("Su tu " + name + ", nang " + weight + " kg, an " + eat + " kg/ngay."); }
}

class Snake extends Animal {
    private double length;
    Snake(String name, double weight, double length) { super(name, weight); this.length = length; }
    void hienThi() { System.out.println("Ran " + name + ", nang " + weight + " kg, dai " + length + " m."); }
}

class Monkey extends Animal {
    private String food;
    Monkey(String name, double weight, String food) { super(name, weight); this.food = food; }
    void hienThi() { System.out.println("Khi " + name + ", nang " + weight + " kg, thich an " + food + "."); }
}

public class AnimalDemo {
    public static void main(String[] args) {
        new Lion("Leo", 300, 5).hienThi();
        new Snake("Boa", 50, 5).hienThi();
        new Monkey("George", 150, "chuoi").hienThi();
    }
}
