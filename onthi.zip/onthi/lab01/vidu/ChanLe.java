import java.util.Scanner;

public class ChanLe {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap so nguyen: ");
        int n = sc.nextInt();
        System.out.println(n % 2 == 0 ? "So chan" : "So le");
    }
}
