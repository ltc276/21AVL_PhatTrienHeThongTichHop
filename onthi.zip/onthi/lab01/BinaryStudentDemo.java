import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class BinaryStudentDemo {
    static class MonHoc {
        String ten; int tinChi; double diem;
        MonHoc(String ten, int tinChi, double diem) { this.ten = ten; this.tinChi = tinChi; this.diem = diem; }
    }
    static class SinhVien {
        String ma, ten; int tuoi; List<MonHoc> monHoc;
        SinhVien(String ma, String ten, int tuoi, List<MonHoc> monHoc) {
            this.ma = ma; this.ten = ten; this.tuoi = tuoi; this.monHoc = monHoc;
        }
    }
    private static void ghi(String tenFile, List<SinhVien> ds) throws IOException {
        try (DataOutputStream out = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(tenFile)))) {
            out.writeInt(ds.size());
            for (SinhVien sv : ds) {
                out.writeUTF(sv.ma); out.writeUTF(sv.ten); out.writeInt(sv.tuoi); out.writeInt(sv.monHoc.size());
                for (MonHoc mh : sv.monHoc) { out.writeUTF(mh.ten); out.writeInt(mh.tinChi); out.writeDouble(mh.diem); }
            }
        }
    }
    private static List<SinhVien> doc(String tenFile) throws IOException {
        List<SinhVien> ds = new ArrayList<>();
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(tenFile)))) {
            int soSV = in.readInt();
            for (int i = 0; i < soSV; i++) {
                String ma = in.readUTF(), ten = in.readUTF(); int tuoi = in.readInt(); int soMH = in.readInt();
                List<MonHoc> monHoc = new ArrayList<>();
                for (int j = 0; j < soMH; j++) monHoc.add(new MonHoc(in.readUTF(), in.readInt(), in.readDouble()));
                ds.add(new SinhVien(ma, ten, tuoi, monHoc));
            }
        }
        return ds;
    }
    public static void main(String[] args) throws Exception {
        String file = args.length == 1 ? args[0] : "data/sinhvien.dat";
        List<MonHoc> mh = List.of(new MonHoc("Java", 3, 8.5), new MonHoc("Mang", 3, 7.5));
        List<SinhVien> ds = List.of(new SinhVien("25000901", "Le Tan Cuong", 21, mh), new SinhVien("25000902", "Nguyen Van A", 20, mh));
        Path.of(file).toAbsolutePath().getParent().toFile().mkdirs();
        ghi(file, ds);
        System.out.println("Da ghi file nhi phan: " + file);
        for (SinhVien sv : doc(file)) {
            System.out.println(sv.ma + " - " + sv.ten + " - " + sv.tuoi + " tuoi");
            for (MonHoc m : sv.monHoc) System.out.println("  " + m.ten + ", TC=" + m.tinChi + ", diem=" + m.diem);
        }
    }
}
