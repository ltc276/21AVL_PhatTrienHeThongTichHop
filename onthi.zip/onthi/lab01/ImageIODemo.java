import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

public class ImageIODemo {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.out.println("Cach dung: java ImageIODemo <anh-nguon> <anh-dich.png>");
            return;
        }
        BufferedImage anh = ImageIO.read(new File(args[0]));
        if (anh == null) { System.out.println("Khong doc duoc dinh dang anh"); return; }
        String dinhDang = args[1].toLowerCase().endsWith(".jpg") || args[1].toLowerCase().endsWith(".jpeg") ? "jpg" : "png";
        if (!ImageIO.write(anh, dinhDang, new File(args[1]))) throw new IllegalArgumentException("Khong co bo ghi " + dinhDang);
        System.out.println("Da ghi anh " + anh.getWidth() + "x" + anh.getHeight() + " vao " + args[1]);
    }
}
