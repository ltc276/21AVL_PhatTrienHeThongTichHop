import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;

public class CopyFileDemo {
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.out.println("Cach dung: java CopyFileDemo <file-nguon> <file-dich>");
            return;
        }
        Path nguon = Path.of(args[0]);
        Path dich = Path.of(args[1]);
        if (!Files.isRegularFile(nguon)) { System.out.println("File nguon khong ton tai"); return; }
        try (InputStream in = Files.newInputStream(nguon); OutputStream out = Files.newOutputStream(dich)) {
            byte[] buffer = new byte[8192];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
        System.out.println("Sao chep thanh cong: " + Files.size(dich) + " byte");
    }
}
