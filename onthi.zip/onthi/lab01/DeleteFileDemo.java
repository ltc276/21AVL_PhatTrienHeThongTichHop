import java.nio.file.Files;
import java.nio.file.Path;

public class DeleteFileDemo {
    public static void main(String[] args) throws Exception {
        if (args.length != 1) {
            System.out.println("Cach dung: java DeleteFileDemo <duong-dan-file>");
            return;
        }
        Path p = Path.of(args[0]);
        if (!Files.exists(p)) {
            System.out.println("File khong ton tai");
            return;
        }
        if (!Files.isRegularFile(p)) {
            System.out.println("Duong dan khong phai file thuong");
            return;
        }
        System.out.println(Files.deleteIfExists(p) ? "Da xoa file" : "Khong xoa duoc file");
    }
}
