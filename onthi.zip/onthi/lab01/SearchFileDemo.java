import java.nio.file.Files;
import java.nio.file.Path;

public class SearchFileDemo {
    private static void tim(Path p, String duoi) throws Exception {
        if (Files.isRegularFile(p) && p.getFileName().toString().endsWith(duoi))
            System.out.println(p.toAbsolutePath());
        if (Files.isDirectory(p)) {
            try (var ds = Files.list(p)) {
                for (Path con : ds.toList()) tim(con, duoi);
            }
        }
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 2) {
            System.out.println("Cach dung: java SearchFileDemo <thu-muc> <duoi-file-vi-du-.txt>");
            return;
        }
        Path root = Path.of(args[0]);
        if (!Files.exists(root)) { System.out.println("Duong dan khong ton tai"); return; }
        tim(root, args[1]);
    }
}
