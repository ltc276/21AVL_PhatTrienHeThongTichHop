import java.util.Scanner;

class HCN {
    private double dai, rong;
    HCN() { this(1, 1); }
    HCN(double dai, double rong) { setDai(dai); setRong(rong); }
    public double getDai() { return dai; }
    public double getRong() { return rong; }
    public void setDai(double dai) { if (dai <= 0) throw new IllegalArgumentException("Dai phai > 0"); this.dai = dai; }
    public void setRong(double rong) { if (rong <= 0) throw new IllegalArgumentException("Rong phai > 0"); this.rong = rong; }
    public double chuVi() { return 2 * (dai + rong); }
    public double dienTich() { return dai * rong; }
    public void xuat() { System.out.printf("HCN: dai=%.2f, rong=%.2f, CV=%.2f, DT=%.2f%n", dai, rong, chuVi(), dienTich()); }
}
class HVuong extends HCN {
    HVuong() { super(1, 1); }
    HVuong(double canh) { super(canh, canh); }
    @Override public void setDai(double canh) { super.setDai(canh); super.setRong(canh); }
    @Override public void setRong(double canh) { super.setDai(canh); super.setRong(canh); }
    public void setCanh(double canh) { setDai(canh); }
    public double getCanh() { return getDai(); }
    @Override public void xuat() { System.out.printf("Hinh vuong: canh=%.2f, CV=%.2f, DT=%.2f%n", getCanh(), chuVi(), dienTich()); }
}
class HTG {
    private double a, b, c;
    HTG() { this(3, 4, 5); }
    HTG(double a, double b, double c) { setCanh(a, b, c); }
    public double getA() { return a; } public double getB() { return b; } public double getC() { return c; }
    public void setA(double a) { setCanh(a, b, c); } public void setB(double b) { setCanh(a, b, c); } public void setC(double c) { setCanh(a, b, c); }
    public void setCanh(double a, double b, double c) {
        if (a <= 0 || b <= 0 || c <= 0 || a + b <= c || a + c <= b || b + c <= a) throw new IllegalArgumentException("Ba canh khong tao thanh tam giac");
        this.a = a; this.b = b; this.c = c;
    }
    public double chuVi() { return a + b + c; }
    public double dienTich() { double p = chuVi() / 2; return Math.sqrt(p * (p-a) * (p-b) * (p-c)); }
    public void xuat() { System.out.printf("Tam giac: %.2f, %.2f, %.2f; CV=%.2f, DT=%.2f%n", a, b, c, chuVi(), dienTich()); }
}
public class Bai1_DemoHinh {
    public static void main(String[] args) {
        new HCN().xuat(); new HCN(5, 3).xuat();
        new HVuong().xuat(); new HVuong(4).xuat();
        new HTG().xuat(); new HTG(6, 6, 6).xuat();
    }
}
