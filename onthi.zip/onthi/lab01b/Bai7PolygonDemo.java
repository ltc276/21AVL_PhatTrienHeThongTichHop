import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
interface Polygon {
    double area();
    double perimeter();
}
class Point2D {
    final double x,y;
    Point2D(double x,double y) {
        this.x=x;
        this.y=y;
    }
}
abstract class BasePolygon implements Polygon {
    protected final List<Point2D> p;
    BasePolygon(List<Point2D> p,int soDinh) {
        if(p.size()!=soDinh)throw new IllegalArgumentException("Sai so dinh");
        this.p=new ArrayList<>(p);
        if (area() < 1e-9) throw new IllegalArgumentException("Dien tich phai lon hon 0; kiem tra toa do dinh");
    }
    public double perimeter() {
        double s=0;
        for(int i=0;i<p.size();i++) {
            Point2D a=p.get(i),b=p.get((i+1)%p.size());
            s+=Math.hypot(a.x-b.x,a.y-b.y);
        }
        return s;
    }
    public double area() {
        double s=0;
        for(int i=0;i<p.size();i++) {
            Point2D a=p.get(i),b=p.get((i+1)%p.size());
            s+=a.x*b.y-b.x*a.y;
        }
        return Math.abs(s)/2;
    }
    public boolean cungToaDo(BasePolygon other) {
        if(p.size()!=other.p.size())return false;
        int n=p.size();
        for(int start=0;start<n;start++)for(int dir:new int[] {
            1,-1
        }
        ) {
            boolean ok=true;
            for(int i=0;i<n;i++) {
                Point2D a=p.get(i),b=other.p.get((start+dir*i+n*2)%n);
                if(Math.abs(a.x-b.x)>1e-9||Math.abs(a.y-b.y)>1e-9) {
                    ok=false;
                    break;
                }
            }
            if(ok)return true;
        }
        return false;
    }
}
class Triangle extends BasePolygon {
    Triangle(List<Point2D> p) {
        super(p,3);
    }
}
class Quadrilateral extends BasePolygon {
    Quadrilateral(List<Point2D> p) {
        super(p,4);
    }
}
class Pentagon extends BasePolygon {
    Pentagon(List<Point2D> p) {
        super(p,5);
    }
}
class Hexagon extends BasePolygon {
    Hexagon(List<Point2D> p) {
        super(p,6);
    }
}
class Octagon extends BasePolygon {
    Octagon(List<Point2D> p) {
        super(p,8);
    }
}
class IsoscelesTriangle extends Triangle {
    IsoscelesTriangle(List<Point2D> p) {
        super(p);
        double a = canh(0), b = canh(1), c = canh(2);
        if (!ganBang(a, b) && !ganBang(a, c) && !ganBang(b, c))
            throw new IllegalArgumentException("Tam giac can phai co it nhat hai canh bang nhau");
    }
    protected double canh(int i) {
        Point2D a = p.get(i), b = p.get((i + 1) % p.size());
        return Math.hypot(a.x - b.x, a.y - b.y);
    }
    protected boolean ganBang(double a, double b) { return Math.abs(a - b) < 1e-9; }
}
class EquilateralTriangle extends IsoscelesTriangle {
    EquilateralTriangle(List<Point2D> p) {
        super(p);
        if (!ganBang(canh(0), canh(1)) || !ganBang(canh(1), canh(2)))
            throw new IllegalArgumentException("Tam giac deu phai co ba canh bang nhau");
    }
}
class Rectangle extends Quadrilateral {
    Rectangle(List<Point2D> p) {
        super(p);
        double a = canh(0), b = canh(1), c = canh(2), d = canh(3);
        Point2D p0 = p.get(0), p1 = p.get(1), p2 = p.get(2);
        double dot = (p1.x - p0.x) * (p2.x - p1.x) + (p1.y - p0.y) * (p2.y - p1.y);
        if (Math.abs(a - c) > 1e-9 || Math.abs(b - d) > 1e-9 || Math.abs(dot) > 1e-9)
            throw new IllegalArgumentException("Toa do khong tao thanh hinh chu nhat");
    }
    protected double canh(int i) {
        Point2D a = p.get(i), b = p.get((i + 1) % p.size());
        return Math.hypot(a.x - b.x, a.y - b.y);
    }
}
class Square extends Rectangle {
    Square(List<Point2D> p) {
        super(p);
        double a = canh(0);
        for (int i = 1; i < 4; i++) if (Math.abs(a - canh(i)) > 1e-9)
            throw new IllegalArgumentException("Hinh vuong phai co bon canh bang nhau");
    }
}
public class Bai7PolygonDemo {
    private static BasePolygon nhap(Scanner sc,String loai,int n) {
        List<Point2D> p=new ArrayList<>();
        System.out.println("Nhap toa do "+n+" dinh (x y), theo thu tu quanh hinh:");
        for(int i=0;i<n;i++)p.add(new Point2D(sc.nextDouble(),sc.nextDouble()));
        return switch(loai) {
            case "1"->new Triangle(p);
            case "2"->new Quadrilateral(p);
            case "3"->new Pentagon(p);
            case "4"->new Hexagon(p);
            case "5"->new Octagon(p);
            case "6"->new IsoscelesTriangle(p);
            case "7"->new EquilateralTriangle(p);
            case "8"->new Rectangle(p);
            case "9"->new Square(p);
            default->throw new IllegalArgumentException("Loai khong hop le");
        }
        ;
    }
    private static int soDinh(String loai) {
        return switch(loai) {
            case "1","6","7"->3;
            case "2","8","9"->4;
            case "3"->5;
            case "4"->6;
            case "5"->8;
            default->throw new IllegalArgumentException("Loai khong hop le");
        }
        ;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("1 Triangle  2 Quadrilateral  3 Pentagon  4 Hexagon  5 Octagon  6 IsoscelesTriangle  7 EquilateralTriangle  8 Rectangle  9 Square");
        System.out.print("Chon loai hinh: ");
        String loai=sc.next();
        try {
            BasePolygon a=nhap(sc,loai,soDinh(loai));
            System.out.printf("Dien tich=%.4f, chu vi=%.4f%n",a.area(),a.perimeter());
            System.out.print("Kiem tra hinh thu hai cung loai? (y/n): ");
            if(sc.next().equalsIgnoreCase("y")) {
                BasePolygon b=nhap(sc,loai,soDinh(loai));
                System.out.println("Trung nhau theo toa do dinh (co tinh xoay thu tu): "+a.cungToaDo(b));
            }
        } catch (IllegalArgumentException e) {
            System.out.println("Hinh khong hop le: " + e.getMessage());
        }
    }
}
