import java.util.Scanner;
public class Student extends Person {
    private double diemTB;
    private String email;
    public Student() {
        super();
        this.diemTB=0;
        this.email="";
    }
    public Student(double diemTB, String email) {
        setDiemTB(diemTB);
        setEmail(email);
    }
    public double getDiemTB() {
        return diemTB;
    }
    public void setDiemTB(double v) {
        if(v<0||v>10)throw new IllegalArgumentException("Diem phai trong 0..10");
        diemTB=v;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String v) {
        if(v==null||!v.contains("@")||v.chars().anyMatch(Character::isWhitespace))throw new IllegalArgumentException("Email phai co @ va khong co khoang trang");
        email=v;
    }
    @Override public void inputInfo(Scanner sc) {
        super.inputInfo(sc);
        while(true) {
            try {
                System.out.print("Diem trung binh (0-10): ");
                setDiemTB(Double.parseDouble(sc.nextLine()));
                break;
            }
            catch(Exception e) {
                System.out.println("Diem khong hop le, nhap lai.");
            }
        }
        while(true) {
            try {
                System.out.print("Email: ");
                setEmail(sc.nextLine());
                break;
            }
            catch(Exception e) {
                System.out.println("Email khong hop le, nhap lai.");
            }
        }
    }
    @Override public void printInfo() {
        super.printInfo();
        System.out.println("Diem TB: "+diemTB+", Email: "+email+", Hoc bong: "+(duocHocBong()?"Co":"Khong"));
    }
    public boolean duocHocBong() {
        return diemTB>8.0;
    }
}
