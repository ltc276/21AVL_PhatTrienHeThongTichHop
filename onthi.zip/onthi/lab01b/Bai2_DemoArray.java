import java.util.Arrays;
import java.util.Scanner;

class MangSoNguyen {
    private final int[] a;
    private int n;
    MangSoNguyen(int max) { if (max <= 0) throw new IllegalArgumentException("n phai > 0"); a = new int[max]; }
    int size() { return n; }
    void nhap(Scanner sc) {
        System.out.print("So phan tu: "); int m = sc.nextInt();
        if (m < 0 || m > a.length) throw new IllegalArgumentException("So phan tu vuot suc chua");
        n = m; for (int i = 0; i < n; i++) { System.out.print("a[" + i + "]="); a[i] = sc.nextInt(); }
    }
    void xuat() { System.out.println(Arrays.toString(Arrays.copyOf(a, n))); }
    boolean them(int viTri, int y) {
        if (n == a.length || viTri < 0 || viTri > n) return false;
        for (int i = n; i > viTri; i--) a[i] = a[i-1]; a[viTri] = y; n++; return true;
    }
    boolean xoaViTri(int j) {
        if (j < 0 || j >= n) return false;
        for (int i = j; i < n-1; i++) a[i] = a[i+1]; n--; return true;
    }
    int xoaGiaTri(int x) { int dem = 0; for (int i = 0; i < n;) { if (a[i] == x) { xoaViTri(i); dem++; } else i++; } return dem; }
    // Chuyen int thanh khoa khong am theo thu tu co dau, sau do LSD Radix Sort.
    void radixTang() {
        int[] b = new int[n]; int[] khoa = new int[n];
        for (int i=0;i<n;i++) khoa[i] = a[i] ^ Integer.MIN_VALUE;
        for (int exp=0; exp<32; exp+=8) {
            int[] count = new int[256];
            for (int x:khoa) count[(x >>> exp)&255]++;
            for (int i=1;i<256;i++) count[i]+=count[i-1];
            for (int i=n-1;i>=0;i--) { int digit=(khoa[i]>>>exp)&255; b[--count[digit]]=khoa[i]; }
            int[] t=khoa; khoa=b; b=t;
        }
        for (int i=0;i<n;i++) a[i]=khoa[i]^Integer.MIN_VALUE;
    }
    void radixGiam() { radixTang(); for (int i=0,j=n-1;i<j;i++,j--) { int t=a[i];a[i]=a[j];a[j]=t; } }
    int timTuyenTinh(int x) { for(int i=0;i<n;i++) if(a[i]==x)return i; return -1; }
    int timNhiPhan(int x) { int l=0,r=n-1; while(l<=r){int m=(l+r)/2;if(a[m]==x)return m;if(a[m]<x)l=m+1;else r=m-1;}return -1; }
    boolean daTang() { for(int i=1;i<n;i++)if(a[i-1]>a[i])return false;return true; }
}
public class Bai2_DemoArray {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); System.out.print("Suc chua toi da: ");
        MangSoNguyen m = new MangSoNguyen(sc.nextInt()); m.nhap(sc); m.xuat();
        System.out.print("Gia tri Y them vao dau: "); m.them(0, sc.nextInt()); m.xuat();
        System.out.print("Gia tri Y them vao cuoi: "); m.them(m.size(), sc.nextInt()); m.xuat();
        System.out.print("Gia tri Y va vi tri i (0-based): "); int y=sc.nextInt(), i=sc.nextInt(); System.out.println("Them: "+m.them(i,y));m.xuat();
        System.out.print("Gia tri X can xoa tat ca: "); System.out.println("Da xoa "+m.xoaGiaTri(sc.nextInt())+" phan tu");m.xuat();
        System.out.print("Vi tri j can xoa (0-based): "); System.out.println("Xoa: "+m.xoaViTri(sc.nextInt()));m.xuat();
        System.out.print("B can tim tren mang chua sap xep: "); int b=sc.nextInt();
        System.out.println("Tim tuyen tinh: "+m.timTuyenTinh(b));
        System.out.println("Radix tang dan:"); m.radixTang(); m.xuat();
        if(m.daTang()) System.out.println("Tim nhi phan tren mang da sap xep: "+m.timNhiPhan(b));
        System.out.println("Radix giam dan:");m.radixGiam();m.xuat();
    }
}
