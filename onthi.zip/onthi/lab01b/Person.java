import java.util.Scanner;
public class Person {
    private String ten, gioiTinh, ngaySinh, diaChi;
    public Person() {
        this("", "", "", "");
    }
    public Person(String ten, String gioiTinh, String ngaySinh, String diaChi) {
        this.ten=ten;
        this.gioiTinh=gioiTinh;
        this.ngaySinh=ngaySinh;
        this.diaChi=diaChi;
    }
    public String getTen() {
        return ten;
    }
    public void setTen(String v) {
        ten=v;
    }
    public String getGioiTinh() {
        return gioiTinh;
    }
    public void setGioiTinh(String v) {
        gioiTinh=v;
    }
    public String getNgaySinh() {
        return ngaySinh;
    }
    public void setNgaySinh(String v) {
        ngaySinh=v;
    }
    public String getDiaChi() {
        return diaChi;
    }
    public void setDiaChi(String v) {
        diaChi=v;
    }
    public void inputInfo(Scanner sc) {
        System.out.print("Ho ten: ");
        ten=sc.nextLine();
        System.out.print("Gioi tinh: ");
        gioiTinh=sc.nextLine();
        System.out.print("Ngay sinh: ");
        ngaySinh=sc.nextLine();
        System.out.print("Dia chi: ");
        diaChi=sc.nextLine();
    }
    public void printInfo() {
        System.out.println("Ho ten: "+ten+", Gioi tinh: "+gioiTinh+", Ngay sinh: "+ngaySinh+", Dia chi: "+diaChi);
    }
}
