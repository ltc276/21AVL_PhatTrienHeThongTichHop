import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StudentDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap so sinh vien: ");
        int n = Integer.parseInt(sc.nextLine());
        if (n <= 0) { System.out.println("n phai > 0"); return; }
        List<Student> ds = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.println("--- Sinh vien " + (i + 1) + " ---");
            Student s = new Student(); s.inputInfo(sc); ds.add(s);
        }
        Student max = ds.get(0), min = ds.get(0);
        System.out.println("\nDANH SACH:");
        for (Student s : ds) { s.printInfo(); if (s.getDiemTB() > max.getDiemTB()) max = s; if (s.getDiemTB() < min.getDiemTB()) min = s; }
        System.out.println("\nDiem cao nhat:"); max.printInfo();
        System.out.println("Diem thap nhat:"); min.printInfo();
        System.out.println("Sinh vien hoc bong:");
        for (Student s : ds) if (s.duocHocBong()) s.printInfo();
    }
}
