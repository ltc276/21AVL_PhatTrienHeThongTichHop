class A {
    protected int x;
    public void setAX(int value) { this.x = value; } // Phuong thuc nay gan dung truong x khai bao trong A.
    public int getAX() { return x; }
}
class B extends A {
    protected int x;
    public void setBX(int value) { this.x=value; }
    public int getBX() { return x; }
}
class C extends B {
    protected int x;
    public void setCX(int value) { this.x=value; }
    public int getCX() { return x; }
    public void thayDoiXcuaA(int value) { setAX(value); }
}
public class Bai6ABC {
    public static void main(String[] args) {
        C c=new C();c.setAX(1);c.setBX(2);c.setCX(3);
        System.out.println("Truoc: A.x="+c.getAX()+", B.x="+c.getBX()+", C.x="+c.getCX());
        c.thayDoiXcuaA(99);
        System.out.println("Sau:   A.x="+c.getAX()+", B.x="+c.getBX()+", C.x="+c.getCX());
    }
}
